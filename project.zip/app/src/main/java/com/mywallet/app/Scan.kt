package com.mywallet.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

data class ScanResult(val amt: Double, val date: String, val name: String)

fun loadBitmap(ctx: Context, uri: Uri, max: Int): Bitmap {
    val cr = ctx.contentResolver
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > max * 2) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    val raw = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }!!
    val rot: Float = try {
        cr.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f
                3 -> 180f
                8 -> 270f
                else -> 0f
            }
        }
    } catch (e: Exception) { 0f }
    val k = minOf(1f, max.toFloat() / maxOf(raw.width, raw.height))
    val m = Matrix()
    m.postRotate(rot)
    m.postScale(k, k)
    return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
}

/** Saves the receipt photo inside the app's private storage and returns its path. */
fun saveReceipt(ctx: Context, bmp: Bitmap): String {
    val dir = File(ctx.filesDir, "receipts").apply { mkdirs() }
    val f = File(dir, uid() + ".jpg")
    FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
    return f.absolutePath
}

/** On-device text recognition (ML Kit). Works offline. */
fun recognize(bmp: Bitmap, ok: (String) -> Unit, fail: () -> Unit) {
    val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    rec.process(InputImage.fromBitmap(bmp, 0))
        .addOnSuccessListener { ok(it.text) }
        .addOnFailureListener { fail() }
}

private val NUM = Regex("""\d[\d.,]*\d|\d""")
private val DEC = Regex("""^(.*\d)[.,](\d{1,2})$""")

private fun toNum(raw: String): Double {
    val s = raw.replace(Regex("[^\\d.,]"), "")
    if (s.isEmpty()) return 0.0
    val m = DEC.find(s)
    if (m != null) return (m.groupValues[1].replace(Regex("[.,]"), "") + "." + m.groupValues[2]).toDoubleOrNull() ?: 0.0
    return s.replace(Regex("[.,]"), "").toDoubleOrNull() ?: 0.0
}

private fun nums(l: String): List<Double> =
    NUM.findAll(l).map { toNum(it.value) }.filter { it > 0 && it < 1e10 }.toList()

fun parseReceipt(text: String): ScanResult {
    val lines = text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    fun pick(re: Regex, ex: Regex?): Double {
        var m = 0.0
        lines.forEachIndexed { i, l ->
            if (re.containsMatchIn(l) && !(ex != null && ex.containsMatchIn(l))) {
                var n = nums(l)
                if (n.isEmpty() && i + 1 < lines.size) n = nums(lines[i + 1])
                if (n.isNotEmpty()) m = maxOf(m, n.max())
            }
        }
        return m
    }

    val opt = setOf(RegexOption.IGNORE_CASE)
    var best = pick(
        Regex("grand\\s*total|total\\s*(bayar|belanja|tagihan|akhir|amount)|amount\\s*due|jumlah\\s*(bayar|tagihan)?|tagihan|total", opt),
        Regex("sub\\s*-?\\s*total|qty|items?\\b|kembali|change|diskon|discount|tax|pajak", opt)
    )
    if (best == 0.0) best = pick(Regex("sub\\s*-?\\s*total|bayar|tunai|cash|total", opt), null)
    if (best == 0.0) {
        val skip = Regex("\\d{1,2}[/\\-.]\\d{1,2}[/\\-.]\\d{2,4}|telp|phone|npwp|no\\.?\\s", opt)
        for (l in lines) if (!skip.containsMatchIn(l)) for (n in nums(l)) if (n > best && n < 1e8) best = n
    }

    // date
    val now = LocalDate.now()
    fun ok(y0: Int, m: Int, d: Int): String {
        val y = if (y0 < 100) y0 + 2000 else y0
        if (y < 2000 || y > now.year + 1 || m < 1 || m > 12 || d < 1 || d > 31) return ""
        return try {
            val dt = LocalDate.of(y, m, d)
            if (dt.isAfter(now.plusDays(1))) "" else dt.toString()
        } catch (e: Exception) { "" }
    }
    val mon = mapOf("jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "mei" to 5, "may" to 5, "jun" to 6, "jul" to 7,
        "agu" to 8, "aug" to 8, "sep" to 9, "okt" to 10, "oct" to 10, "nov" to 11, "des" to 12, "dec" to 12)
    val r1 = Regex("(\\d{4})[/\\-.](\\d{1,2})[/\\-.](\\d{1,2})")
    val r2 = Regex("(\\d{1,2})[/\\-.](\\d{1,2})[/\\-.](\\d{2,4})")
    val r3 = Regex("(\\d{1,2})\\s*[-\\s]\\s*(jan|feb|mar|apr|mei|may|jun|jul|agu|aug|sep|okt|oct|nov|des|dec)[a-z]*\\.?\\s*[-\\s]?\\s*(\\d{2,4})", opt)
    var date = ""
    for (l in lines) {
        r1.find(l)?.let { date = ok(it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toInt()) }
        if (date.isEmpty()) r2.find(l)?.let { date = ok(it.groupValues[3].toInt(), it.groupValues[2].toInt(), it.groupValues[1].toInt()) }
        if (date.isEmpty()) r3.find(l)?.let { date = ok(it.groupValues[3].toInt(), mon[it.groupValues[2].lowercase()] ?: 0, it.groupValues[1].toInt()) }
        if (date.isNotEmpty()) break
    }

    // merchant name: first line with mostly letters
    var name = ""
    val bad = Regex("receipt|struk|invoice|www\\.|http", opt)
    for (l in lines.take(6)) {
        val a = l.count { it.isLetter() }
        if (a >= 3 && a >= l.length * 0.5 && !bad.containsMatchIn(l)) {
            name = l.replace(Regex("[^A-Za-z0-9&' .\\-]"), "").trim().take(40)
            break
        }
    }
    return ScanResult(best, date, name)
}

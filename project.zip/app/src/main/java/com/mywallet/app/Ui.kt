package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

val Accents = listOf(0xFF6C5CE7, 0xFF0984E3, 0xFF00B894, 0xFFE17055, 0xFFEC4899, 0xFF64748B, 0xFF06B6D4, 0xFF3F8F3F, 0xFFB87B2A)
const val DEFAULT_ACCENT = 4
val Green = Color(0xFF12A36B)
val Red = Color(0xFFE5484D)
val Amber = Color(0xFFF5A524)
val ChartColors = listOf(0xFF6C5CE7, 0xFF0984E3, 0xFF00B894, 0xFFE17055, 0xFFEC4899, 0xFFF5A524, 0xFF64748B, 0xFF06B6D4, 0xFF3F8F3F).map { Color(it) }

/* ---------------- fonts / theme ---------------- */

@OptIn(ExperimentalTextApi::class)
@Composable
fun rememberFont(): FontFamily {
    val ctx = LocalContext.current
    return remember {
        try {
            if (ctx.assets.list("fonts")?.contains("PlusJakartaSans.ttf") == true) {
                FontFamily(listOf(400, 500, 600, 700, 800).map { w ->
                    Font("fonts/PlusJakartaSans.ttf", ctx.assets, FontWeight(w), FontStyle.Normal, FontVariation.Settings(FontVariation.weight(w)))
                })
            } else FontFamily.Default
        } catch (e: Throwable) {
            FontFamily.Default
        }
    }
}

fun Typography.withFont(f: FontFamily) = copy(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f), displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f), headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f), titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f), bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f), labelSmall = labelSmall.copy(fontFamily = f)
)

@Composable
fun AppTheme(dark: Boolean, accent: Color, content: @Composable () -> Unit) {
    val cs = if (dark) darkColorScheme(
        primary = accent, onPrimary = Color.White,
        background = Color(0xFF14151F), onBackground = Color(0xFFF1F2F8),
        surface = Color(0xFF1E2030), onSurface = Color(0xFFF1F2F8),
        surfaceVariant = Color(0xFF2A2C40), onSurfaceVariant = Color(0xFF9A9EB5),
        outline = Color(0xFF34374D)
    ) else lightColorScheme(
        primary = accent, onPrimary = Color.White,
        background = Color(0xFFF5F6FA), onBackground = Color(0xFF14151F),
        surface = Color.White, onSurface = Color(0xFF14151F),
        surfaceVariant = Color(0xFFECEEF5), onSurfaceVariant = Color(0xFF7B7F93),
        outline = Color(0xFFECECF3)
    )
    MaterialTheme(colorScheme = cs, typography = Typography().withFont(rememberFont()), content = content)
}

/* ---------------- cute icon set (from the HTML app) ---------------- */

fun icoRes(k: String): Int = when (k) {
        "add" -> R.drawable.c_add
        "al" -> R.drawable.c_al
        "bank" -> R.drawable.c_bank
        "bills" -> R.drawable.c_bills
        "bk" -> R.drawable.c_bk
        "cal" -> R.drawable.c_cal
        "calc" -> R.drawable.c_calc
        "cash" -> R.drawable.c_cash
        "ch" -> R.drawable.c_ch
        "cloud" -> R.drawable.c_cloud
        "cur" -> R.drawable.c_cur
        "dl" -> R.drawable.c_dl
        "dn" -> R.drawable.c_dn
        "education" -> R.drawable.c_education
        "food" -> R.drawable.c_food
        "fun" -> R.drawable.c_fun
        "gg" -> R.drawable.c_gg
        "gift" -> R.drawable.c_gift
        "gl" -> R.drawable.c_gl
        "groceries" -> R.drawable.c_groceries
        "health" -> R.drawable.c_health
        "home" -> R.drawable.c_home
        "img" -> R.drawable.c_img
        "info" -> R.drawable.c_info
        "lf" -> R.drawable.c_lf
        "lock" -> R.drawable.c_lock
        "logo" -> R.drawable.c_logo
        "mail" -> R.drawable.c_mail
        "moon" -> R.drawable.c_moon
        "more" -> R.drawable.c_more
        "other" -> R.drawable.c_other
        "out" -> R.drawable.c_out
        "pen" -> R.drawable.c_pen
        "pets" -> R.drawable.c_pets
        "ph" -> R.drawable.c_ph
        "pl" -> R.drawable.c_pl
        "rs" -> R.drawable.c_rs
        "rt" -> R.drawable.c_rt
        "salary" -> R.drawable.c_salary
        "shopping" -> R.drawable.c_shopping
        "st" -> R.drawable.c_st
        "sun" -> R.drawable.c_sun
        "swap" -> R.drawable.c_swap
        "tag" -> R.drawable.c_tag
        "tg" -> R.drawable.c_tg
        "th" -> R.drawable.c_th
        "tr" -> R.drawable.c_tr
        "transport" -> R.drawable.c_transport
        "travel" -> R.drawable.c_travel
        "ul" -> R.drawable.c_ul
        "up" -> R.drawable.c_up
        "us" -> R.drawable.c_us
        "x" -> R.drawable.c_x
    else -> R.drawable.c_tag
}

@Composable
fun Ico(k: String, size: Dp = 24.dp, modifier: Modifier = Modifier, tint: Color? = null) {
    Image(
        painterResource(icoRes(k)), null, modifier.size(size),
        colorFilter = if (tint != null) ColorFilter.tint(tint) else null
    )
}

fun catIcon(c: String): String = when (c) {
    "Food", "Drink", "Coffee" -> "food"
    "Transport" -> "transport"
    "Shopping" -> "shopping"
    "Bills" -> "bills"
    "Health" -> "health"
    "Fun" -> "fun"
    "Other" -> "other"
    "Groceries" -> "groceries"
    "Education" -> "education"
    "Travel" -> "travel"
    "Pets" -> "pets"
    "Gifts", "Gift", "Bonus" -> "gift"
    "Salary" -> "salary"
    else -> "tag"
}

fun accIcon(a: String): String = when (a) {
    "Bank" -> "bank"
    "Cash" -> "cash"
    "E-wallet" -> "ph"
    else -> "cur"
}

/* ---------------- small building blocks ---------------- */

@Composable
fun tint(): Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)

@Composable
fun IconTile(k: String, size: Dp = 48.dp, icon: Dp = 28.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(tint()), contentAlignment = Alignment.Center) { Ico(k, icon) }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, pad: Dp = 18.dp, content: @Composable ColumnScope.() -> Unit) {
    val c = MaterialTheme.colorScheme
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = c.surface,
        border = BorderStroke(1.dp, c.outline),
        shadowElevation = 3.dp
    ) { Column(Modifier.padding(pad), content = content) }
}

@Composable
fun SectionRow(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        if (action != null) Text(
            action, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(6.dp)
        )
    }
}

@Composable
fun SmallLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(), modifier = modifier, color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp
    )
}

@Composable
fun Muted(text: String, modifier: Modifier = Modifier, size: Int = 13) {
    Text(text, modifier = modifier, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = size.sp)
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (selected) c.primary.copy(alpha = 0.16f) else c.surfaceVariant)
            .border(if (selected) 1.5.dp else 0.dp, if (selected) c.primary else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) c.primary else c.onSurface, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Segmented(opts: List<String>, sel: Int, onSel: (Int) -> Unit, modifier: Modifier = Modifier, size: Int = 15) {
    val c = MaterialTheme.colorScheme
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(c.surfaceVariant).padding(5.dp)) {
        opts.forEachIndexed { i, o ->
            val on = i == sel
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(17.dp))
                    .background(if (on) c.surface else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(o, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, color = if (on) c.onSurface else c.onSurfaceVariant, fontSize = size.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun Bar(p: Float, color: Color, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Box(modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(8.dp)).background(c.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(color))
    }
}

fun barColor(p: Float): Color = if (p >= 1f) Red else if (p >= 0.8f) Amber else Green

/** Rounded pill input (matches the HTML app's fields). */
@Composable
fun PillField(
    value: String, onChange: (String) -> Unit, placeholder: String,
    number: Boolean = false, modifier: Modifier = Modifier
) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(c.surface)
            .border(1.dp, c.outline, RoundedCornerShape(24.dp)).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        if (value.isEmpty()) Text(placeholder, color = c.onSurfaceVariant, fontSize = 17.sp)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = c.onSurface, fontSize = 17.sp, fontFamily = MaterialTheme.typography.bodyLarge.fontFamily),
            cursorBrush = androidx.compose.ui.graphics.SolidColor(c.primary),
            keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Decimal else KeyboardType.Text),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun PickPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier.clip(RoundedCornerShape(24.dp)).background(c.surface).border(1.dp, c.outline, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        androidx.compose.material3.Icon(Icons.Default.KeyboardArrowDown, null, tint = c.onSurface)
    }
}

/** options = key to label */
@Composable
fun Dropdown(label: String, options: List<Pair<String, String>>, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        PickPill(label, { open = true }, Modifier.fillMaxWidth())
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (k, l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onSelect(k); open = false }) }
        }
    }
}

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, label: String,
    number: Boolean = false, modifier: Modifier = Modifier, single: Boolean = true
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = single, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Decimal else KeyboardType.Text)
    )
}

fun fmtDate(iso: String): String = try {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.US))
} catch (e: Exception) { iso }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(value: String, label: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    var show by remember { mutableStateOf(false) }
    PickPill(fmtDate(value), { show = true }, modifier.fillMaxWidth())
    if (show) {
        val ms = runCatching { LocalDate.parse(value).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
        val ps = rememberDatePickerState(initialSelectedDateMillis = ms)
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    ps.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
                    show = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } }
        ) { DatePicker(state = ps) }
    }
}

/** A white card containing transaction rows separated by hairlines. */
@Composable
fun TxList(list: List<Tx>, cur: String, onOpen: (String) -> Unit) {
    val c = MaterialTheme.colorScheme
    var all by remember(list.size) { mutableStateOf(false) }
    val shown = if (all) list else list.take(60)
    AppCard(pad = 8.dp) {
        if (list.isEmpty()) Muted("No transactions yet.", Modifier.padding(14.dp), 15)
        shown.forEachIndexed { i, x ->
            if (i > 0) HorizontalDivider(Modifier.padding(horizontal = 12.dp), color = c.outline)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable { onOpen(x.id) }.padding(horizontal = 12.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconTile(catIcon(x.cat), 56.dp, 34.dp)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(x.note.ifBlank { x.cat }, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Muted("${x.cat} · ${x.acc} · ${x.date}", size = 13)
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    (if (x.type == "inc") "+" else "−") + money(cur, x.amt),
                    color = if (x.type == "inc") Green else Red, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp
                )
            }
        }
        if (!all && list.size > 60) TextButton(onClick = { all = true }, modifier = Modifier.fillMaxWidth()) { Text("Show all ${list.size}") }
    }
}

/** Camera icon drawn as vector (used for Scan receipt). */
@Composable
fun CameraIcon(color: Color, size: Dp = 26.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val sw = w * 0.085f
        val body = Path().apply {
            addRoundRect(androidx.compose.ui.geometry.RoundRect(w * 0.08f, w * 0.26f, w * 0.92f, w * 0.84f, w * 0.12f, w * 0.12f))
        }
        drawPath(body, color, style = Stroke(sw, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        drawPath(Path().apply { moveTo(w * 0.32f, w * 0.26f); lineTo(w * 0.40f, w * 0.14f); lineTo(w * 0.60f, w * 0.14f); lineTo(w * 0.68f, w * 0.26f) }, color, style = Stroke(sw, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        drawCircle(color, w * 0.17f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, w * 0.55f), style = Stroke(sw))
    }
}

/** App logo tile in the header: gradient rounded square with a white outline wallet. */
@Composable
fun LogoTile(size: Dp = 48.dp) {
    val c = MaterialTheme.colorScheme
    Box(
        Modifier.size(size).shadow(8.dp, RoundedCornerShape(16.dp), ambientColor = c.primary, spotColor = c.primary)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(c.primary, lerp(c.primary, Color.Black, 0.5f)))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.56f)) {
            val w = this.size.width
            drawRoundRect(Color.White, androidx.compose.ui.geometry.Offset(w * 0.04f, w * 0.26f), androidx.compose.ui.geometry.Size(w * 0.92f, w * 0.66f), androidx.compose.ui.geometry.CornerRadius(w * 0.14f), style = Stroke(w * 0.09f))
            drawCircle(Color(0xFFFFC857), w * 0.1f, androidx.compose.ui.geometry.Offset(w * 0.5f, w * 0.1f))
            drawCircle(Color.White, w * 0.07f, androidx.compose.ui.geometry.Offset(w * 0.74f, w * 0.58f))
        }
    }
}

fun short(v: Double): String {
    val a = Math.abs(v)
    return when {
        a >= 1e9 -> trimZ(v / 1e9) + "B"
        a >= 1e6 -> trimZ(v / 1e6) + "M"
        a >= 1e3 -> trimZ(v / 1e3) + "K"
        else -> trimZ(v)
    }
}
private fun trimZ(v: Double): String = String.format(Locale.US, "%.1f", v).removeSuffix(".0")

package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

val Accents = listOf(0xFFEC4899, 0xFF6C5CE7, 0xFF3B82F6, 0xFF12A36B, 0xFFF59E0B)
val Green = Color(0xFF12A36B)
val Red = Color(0xFFE5484D)
val Amber = Color(0xFFF5A524)

@Composable
fun AppTheme(dark: Boolean, accent: Color, content: @Composable () -> Unit) {
    val cs = if (dark) darkColorScheme(
        primary = accent, onPrimary = Color.White,
        background = Color(0xFF14151F), onBackground = Color(0xFFF1F2F8),
        surface = Color(0xFF1E2030), onSurface = Color(0xFFF1F2F8),
        surfaceVariant = Color(0xFF2A2C40), onSurfaceVariant = Color(0xFF9A9EB5),
        outline = Color(0xFF3A3D55)
    ) else lightColorScheme(
        primary = accent, onPrimary = Color.White,
        background = Color(0xFFF5F6FA), onBackground = Color(0xFF14151F),
        surface = Color.White, onSurface = Color(0xFF14151F),
        surfaceVariant = Color(0xFFEEF0F6), onSurfaceVariant = Color(0xFF7B7F93),
        outline = Color(0xFFDDDFEA)
    )
    MaterialTheme(colorScheme = cs, typography = Typography(), content = content)
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp
    ) { Column(Modifier.padding(16.dp), content = content) }
}

@Composable
fun SectionRow(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (action != null) Text(
            action, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(6.dp)
        )
    }
}

@Composable
fun Muted(text: String, modifier: Modifier = Modifier, size: Int = 13) {
    Text(text, modifier = modifier, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = size.sp)
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (selected) c.primary.copy(alpha = 0.16f) else c.surfaceVariant)
            .border(if (selected) 1.5.dp else 0.dp, if (selected) c.primary else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(label, color = if (selected) c.primary else c.onSurface, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Bar(p: Float, color: Color, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)).background(c.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(color))
    }
}

fun barColor(p: Float): Color = if (p >= 1f) Red else if (p >= 0.8f) Amber else Green

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, label: String,
    number: Boolean = false, modifier: Modifier = Modifier, single: Boolean = true
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = single, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Decimal else KeyboardType.Text)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(value: String, label: String, onChange: (String) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Box {
        OutlinedTextField(
            value = value, onValueChange = {}, readOnly = true, label = { Text(label) },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)
        )
        Box(Modifier.matchParentSize().clickable { show = true })
    }
    if (show) {
        val ms = runCatching { LocalDate.parse(value).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
        val ps = rememberDatePickerState(initialSelectedDateMillis = ms)
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    ps.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
                    show = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } }
        ) { DatePicker(state = ps) }
    }
}

@Composable
fun TxRow(x: Tx, cur: String, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Surface(
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onClick),
        color = c.surface, shape = shape, shadowElevation = 1.dp
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(c.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) { Text(catEmoji(x.cat), fontSize = 22.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(x.note.ifBlank { x.cat }, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Muted("${x.cat} · ${x.acc} · ${x.date}", size = 12)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                (if (x.type == "inc") "+" else "-") + money(cur, x.amt),
                color = if (x.type == "inc") Green else Red, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
        }
    }
}

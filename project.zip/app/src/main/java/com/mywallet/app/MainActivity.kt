package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.isSystemInDarkTheme

import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val store: Store by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App(store) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(st: Store) {
    val d = st.d
    val dark = when (d.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    AppTheme(dark, Color(Accents[d.accent.coerceIn(0, Accents.lastIndex)])) {
        val c = MaterialTheme.colorScheme
        var tab by rememberSaveable { mutableStateOf(0) }
        var overlay by remember { mutableStateOf<String?>(null) } // "new", "xf" or a transaction id
        var detail by remember { mutableStateOf<String?>(null) }

        Box(Modifier.fillMaxSize().background(c.background)) {
            Scaffold(
                containerColor = c.background,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                floatingActionButton = {
                    if (tab == 0 || tab == 2) FloatingActionButton(
                        onClick = { overlay = "new" }, containerColor = c.primary, contentColor = Color.White,
                        shape = RoundedCornerShape(24.dp), modifier = Modifier.size(68.dp)
                    ) { Ico("pen", 44.dp) }
                },
                bottomBar = {
                    Column(Modifier.fillMaxWidth().background(c.surface)) {
                        HorizontalDivider(color = c.outline)
                        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp)) {
                            listOf("home" to "Home", "tg" to "Saving", "ch" to "Reports", "st" to "Settings").forEachIndexed { i, (ic, l) ->
                                val on = tab == i
                                Column(
                                    Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).clickable { tab = i }.padding(vertical = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        Modifier.width(70.dp).height(40.dp).clip(RoundedCornerShape(20.dp))
                                            .background(if (on) c.primary.copy(alpha = 0.16f) else Color.Transparent),
                                        contentAlignment = Alignment.Center
                                    ) { Ico(ic, 30.dp) }
                                    Text(l, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) c.primary else c.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            ) { pad ->
                Column(Modifier.padding(pad).fillMaxSize().statusBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        LogoTile(54.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Muted(if (tab == 0) LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMM d", Locale.US)) else "myWallet", size = 15)
                            Text(
                                if (tab == 0) "Hi, " + d.name.ifBlank { "there" } else listOf("", "Saving", "Reports", "Settings")[tab],
                                fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Box(
                            Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(c.surface).border(1.dp, c.outline, RoundedCornerShape(18.dp)),
                            contentAlignment = Alignment.Center
                        ) { Ico("cal", 32.dp) }
                        Spacer(Modifier.width(10.dp))
                        Box(
                            Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(c.surface).border(1.dp, c.outline, RoundedCornerShape(18.dp))
                                .clickable { st.up { it.copy(theme = if (dark) "light" else "dark") } },
                            contentAlignment = Alignment.Center
                        ) { Ico(if (dark) "sun" else "moon", 32.dp) }
                    }
                    HorizontalDivider(color = c.outline)
                    when (tab) {
                        0 -> HomeScreen(st, { detail = it }, { xf -> overlay = if (xf) "xf" else "new" })
                        1 -> SavingScreen(st)
                        2 -> ReportsScreen(st) { detail = it }
                        else -> SettingsScreen(st)
                    }
                }
            }

            overlay?.let { o -> TxSheet(st, if (o == "new" || o == "xf") null else o, o == "xf") { overlay = null } }
        }

        // transaction details
        detail?.let { id ->
            val x = d.tx.find { it.id == id }
            if (x == null) { detail = null } else { AlertDialog(
                onDismissRequest = { detail = null },
                title = { Text(x.note.ifBlank { x.cat }, fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text((if (x.type == "inc") "+" else "-") + money(d.cur, x.amt), fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = if (x.type == "inc") Green else Red)
                        Muted("${catEmoji(x.cat)} ${x.cat} · ${x.acc}", size = 14)
                        Muted(x.date, size = 14)
                        if (x.rc.isNotEmpty() && File(x.rc).exists()) {
                            val bmp = remember(x.rc) { BitmapFactory.decodeFile(x.rc)?.asImageBitmap() }
                            if (bmp != null) Image(bmp, "Receipt", Modifier.fillMaxWidth().heightIn(max = 360.dp).clip(RoundedCornerShape(14.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { overlay = x.id; detail = null }) { Text("Edit") } },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            st.up { s -> s.copy(tx = s.tx.filter { it.id != x.id }) }
                            if (x.rc.isNotEmpty()) runCatching { File(x.rc).delete() }
                            detail = null
                        }) { Text("Delete", color = Red) }
                        TextButton(onClick = { detail = null }) { Text("Close") }
                    }
                }
            ) }
        }

        // first-run welcome
        if (!d.onboarded) {
            var n by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Welcome to myWallet", fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Muted("Create your profile to get started.", size = 14)
                        Field(n, { n = it }, "Your name")
                    }
                },
                confirmButton = { TextButton(onClick = { st.up { it.copy(name = n.trim(), onboarded = true) } }) { Text("Start", fontWeight = FontWeight.Bold) } }
            )
        }
    }
}

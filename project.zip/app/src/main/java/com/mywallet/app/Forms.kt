package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

fun parseAmt(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

/* ====================== Dialog forms ====================== */

@Composable
fun FormDialog(
    title: String, onClose: () -> Unit, onSave: () -> Unit,
    onDelete: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title, fontWeight = FontWeight.ExtraBold) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = { TextButton(onClick = onSave) { Text("Save", fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete", color = Red) }
                TextButton(onClick = onClose) { Text("Cancel") }
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BudgetDialog(st: Store, old: Budget?, onClose: () -> Unit) {
    val d = st.d
    var name by remember { mutableStateOf(old?.name ?: "") }
    var amt by remember { mutableStateOf(old?.amt?.let { numText(it) } ?: "") }
    var cats by remember { mutableStateOf(old?.cats ?: emptyList()) }
    var kw by remember { mutableStateOf(old?.kw ?: "") }
    FormDialog(if (old == null) "New budget" else "Edit budget", onClose, onSave = {
        val a = parseAmt(amt)
        if (a != null && a > 0) {
            val n = name.trim().ifEmpty { if (cats.size == 1) cats[0] else if (kw.isNotBlank()) kw.trim() else if (cats.isNotEmpty()) "Budget" else "Total spending" }
            val b = Budget(old?.id ?: uid(), n, a, cats, kw.trim())
            st.up { s -> s.copy(bl = if (old != null) s.bl.map { x -> if (x.id == old.id) b else x } else s.bl + b) }
            onClose()
        }
    }, onDelete = old?.let { o -> { st.up { s -> s.copy(bl = s.bl.filter { it.id != o.id }) }; onClose() } }) {
        Field(name, { name = it }, "Name (optional)")
        Field(amt, { amt = it }, "Monthly limit (${d.cur})", number = true)
        Muted("Counts spending from (none selected = all expenses)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            d.expCats.forEach { k -> Chip(catEmoji(k) + " " + k, k in cats, { cats = if (k in cats) cats - k else cats + k }) }
        }
        Field(kw, { kw = it }, "Only notes containing (optional)")
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecDialog(st: Store, old: Rec?, onClose: () -> Unit) {
    val d = st.d
    var type by remember { mutableStateOf(old?.type ?: "exp") }
    var name by remember { mutableStateOf(old?.note ?: "") }
    var amt by remember { mutableStateOf(old?.amt?.let { numText(it) } ?: "") }
    var cat by remember { mutableStateOf(old?.cat ?: "") }
    var acc by remember { mutableStateOf(old?.acc ?: d.accts.firstOrNull().orEmpty()) }
    var freq by remember { mutableStateOf(old?.freq ?: "m") }
    var next by remember { mutableStateOf(old?.next ?: today()) }
    val cats = if (type == "exp") d.expCats else d.incCats
    val curCat = if (cat in cats) cat else (cats.firstOrNull { it == "Other" } ?: cats.firstOrNull() ?: "")
    FormDialog(if (old == null) "New recurring" else "Edit recurring", onClose, onSave = {
        val a = parseAmt(amt)
        if (name.isNotBlank() && a != null && a > 0) {
            val r = Rec(old?.id ?: uid(), type, a, curCat, acc, name.trim(), freq, next)
            st.up { s -> s.copy(rec = if (old != null) s.rec.map { x -> if (x.id == old.id) r else x } else s.rec + r) }
            onClose()
        }
    }, onDelete = old?.let { o -> { st.up { s -> s.copy(rec = s.rec.filter { it.id != o.id }) }; onClose() } }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Expense", type == "exp", { type = "exp" }, Modifier.weight(1f))
            Chip("Income", type == "inc", { type = "inc" }, Modifier.weight(1f))
        }
        Field(name, { name = it }, "Name (rent, Netflix, salary…)")
        Field(amt, { amt = it }, "Amount (${d.cur})", number = true)
        Muted("Category")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            cats.forEach { k -> Chip(catEmoji(k) + " " + k, k == curCat, { cat = k }) }
        }
        Muted("Money place")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            d.accts.forEach { a -> Chip(accEmoji(a) + " " + a, a == acc, { acc = a }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Monthly", freq == "m", { freq = "m" }, Modifier.weight(1f))
            Chip("Weekly", freq == "w", { freq = "w" }, Modifier.weight(1f))
        }
        DateField(next, "Next due") { next = it }
    }
}

@Composable
fun GoalDialog(st: Store, onClose: () -> Unit) {
    val d = st.d
    var name by remember { mutableStateOf("") }
    var goal by remember { mutableStateOf("") }
    FormDialog("New goal", onClose, onSave = {
        val g = parseAmt(goal)
        if (name.isNotBlank() && g != null && g > 0) {
            st.up { s -> s.copy(sv = s.sv + Goal(uid(), name.trim(), g)) }
            onClose()
        }
    }) {
        Field(name, { name = it }, "Goal name")
        Field(goal, { goal = it }, "Target (${d.cur})", number = true)
    }
}

/** Add to / take out from a savings goal. dir = +1 or -1. */
@Composable
fun MoveDialog(st: Store, g: Goal, dir: Int, onClose: () -> Unit) {
    var amt by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    FormDialog(if (dir > 0) "Add to saving" else "Take out from saving", onClose, onSave = {
        val a = parseAmt(amt)
        if (a == null || a <= 0) { err = "Enter an amount" }
        else if (dir < 0 && a > g.saved) { err = "Not enough saved" }
        else {
            st.up { s -> s.copy(sv = s.sv.map { x -> if (x.id == g.id) x.copy(saved = x.saved + dir * a, hist = x.hist + Hist(today(), dir * a)) else x }) }
            onClose()
        }
    }) {
        Field(amt, { amt = it }, "Amount", number = true)
        if (err.isNotEmpty()) Text(err, color = Red)
    }
}

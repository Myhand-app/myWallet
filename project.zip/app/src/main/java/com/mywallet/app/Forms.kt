package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun parseAmt(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

/* ====================== New / edit transaction (full screen) ====================== */

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TxForm(st: Store, editId: String?, onClose: () -> Unit) {
    val d = st.d
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = MaterialTheme.colorScheme
    val old = remember(editId) { d.tx.find { it.id == editId } }

    var type by remember { mutableStateOf(old?.type ?: "exp") }
    var amt by remember { mutableStateOf(old?.amt?.let { numText(it) } ?: "") }
    var name by remember { mutableStateOf(old?.note ?: "") }
    var cat by remember { mutableStateOf(old?.cat ?: "") }
    var acc by remember { mutableStateOf(old?.acc ?: d.accts.firstOrNull().orEmpty()) }
    var date by remember { mutableStateOf(old?.date ?: today()) }
    var rc by remember { mutableStateOf(old?.rc ?: "") }
    var manual by remember { mutableStateOf(old != null) }
    var scanning by remember { mutableStateOf(false) }
    var chooser by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("") }

    val cats = if (type == "exp") d.expCats else d.incCats
    val curCat = if (cat in cats) cat else (cats.firstOrNull { it == "Other" } ?: cats.firstOrNull() ?: "")

    fun process(uri: Uri) {
        scanning = true
        hint = ""
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { loadBitmap(ctx, uri, 1800) }.getOrNull() }
            if (bmp == null) {
                scanning = false
                hint = "Could not read the photo."
                return@launch
            }
            rc = withContext(Dispatchers.IO) { saveReceipt(ctx, bmp) }
            recognize(bmp, { text ->
                val r = parseReceipt(text)
                if (r.amt > 0) { type = "exp"; amt = numText(r.amt) }
                if (r.date.isNotEmpty()) date = r.date
                if (r.name.isNotEmpty() && name.isBlank()) {
                    name = r.name
                    guessCat(r.name)?.let { g -> type = g.first; cat = g.second }
                }
                hint = if (r.amt > 0) "Scanned ${money(d.cur, r.amt)}. Check the details, then save."
                else "Couldn't find the total. Please fill it in."
                scanning = false
            }, {
                scanning = false
                hint = "Couldn't read text from the photo. Fill in manually."
            })
        }
    }

    val camUri = remember {
        val dir = File(ctx.cacheDir, "cam").apply { mkdirs() }
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(dir, "cap.jpg"))
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) process(camUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) process(uri) }

    BackHandler { onClose() }

    Column(
        Modifier.fillMaxSize().background(c.background)
            .statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("✕", fontSize = 22.sp, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onClose() }.padding(8.dp))
            Text(
                if (old != null) "Edit transaction" else "New transaction",
                fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.weight(1f).padding(start = 6.dp)
            )
            // Scan receipt: top right, camera icon
            Box(
                Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(c.primary.copy(alpha = 0.14f))
                    .clickable { chooser = true },
                contentAlignment = Alignment.Center
            ) { Text("📷", fontSize = 24.sp) }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (hint.isNotEmpty()) Muted(hint, size = 14)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Expense", type == "exp", { type = "exp" }, Modifier.weight(1f))
                Chip("Income", type == "inc", { type = "inc" }, Modifier.weight(1f))
            }
            Field(amt, { amt = it }, "Amount (${d.cur})", number = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10000, 25000, 50000, 100000).forEach { n ->
                    Chip("+" + String.format(java.util.Locale.US, "%,d", n), false, {
                        amt = numText((parseAmt(amt) ?: 0.0) + n)
                    })
                }
            }
            Field(name, {
                name = it
                if (!manual) guessCat(it)?.let { g -> type = g.first; cat = g.second }
            }, "Item name")
            Text("Category", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.forEach { k -> Chip(catEmoji(k) + " " + k, k == curCat, { cat = k; manual = true }) }
            }
            Text("Money place", fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                d.accts.forEach { a -> Chip(accEmoji(a) + " " + a, a == acc, { acc = a }) }
            }
            DateField(date, "Date") { date = it }
            if (rc.isNotEmpty() && File(rc).exists()) {
                val bmp = remember(rc) { android.graphics.BitmapFactory.decodeFile(rc)?.asImageBitmap() }
                if (bmp != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(bmp, "Receipt", Modifier.size(84.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(12.dp))
                        TextButton(onClick = { rc = "" }) { Text("Remove receipt", color = Red) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        Button(
            onClick = {
                val a = parseAmt(amt)
                if (a == null || a <= 0) { hint = "Enter a valid amount."; return@Button }
                val t = Tx(old?.id ?: uid(), type, a, curCat, acc, date, name.trim(), rc)
                st.up { s -> s.copy(tx = if (old != null) s.tx.map { x -> if (x.id == old.id) t else x } else s.tx + t) }
                onClose()
            },
            modifier = Modifier.fillMaxWidth().height(54.dp).padding(bottom = 0.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Save", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        Spacer(Modifier.height(10.dp))
    }

    if (chooser) AlertDialog(
        onDismissRequest = { chooser = false },
        title = { Text("Scan receipt") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted("The amount, date and name are filled in automatically.", size = 14)
                Button(onClick = {
                    chooser = false
                    runCatching { File(ctx.cacheDir, "cam/cap.jpg").also { it.parentFile?.mkdirs(); it.createNewFile() } }
                    camLauncher.launch(camUri)
                }, Modifier.fillMaxWidth()) { Text("📷  Take a photo") }
                OutlinedButton(onClick = {
                    chooser = false
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, Modifier.fillMaxWidth()) { Text("🖼️  Choose from gallery") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { chooser = false }) { Text("Cancel") } }
    )
    if (scanning) AlertDialog(
        onDismissRequest = {}, confirmButton = {},
        title = { Text("Reading receipt…") },
        text = { LinearProgressIndicator(Modifier.fillMaxWidth()) }
    )
}

/* ====================== Dialog forms ====================== */

@Composable
private fun FormDialog(
    title: String, onClose: () -> Unit, onSave: () -> Unit,
    onDelete: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title, fontWeight = FontWeight.ExtraBold) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = { TextButton(onClick = onSave) { Text("Save", fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete", color = Red) }
                TextButton(onClick = onClose) { Text("Cancel") }
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BudgetDialog(st: Store, old: Budget?, onClose: () -> Unit) {
    val d = st.d
    var name by remember { mutableStateOf(old?.name ?: "") }
    var amt by remember { mutableStateOf(old?.amt?.let { numText(it) } ?: "") }
    var cats by remember { mutableStateOf(old?.cats ?: emptyList()) }
    var kw by remember { mutableStateOf(old?.kw ?: "") }
    FormDialog(if (old == null) "New budget" else "Edit budget", onClose, onSave = {
        val a = parseAmt(amt)
        if (a != null && a > 0) {
            val n = name.trim().ifEmpty { if (cats.size == 1) cats[0] else if (kw.isNotBlank()) kw.trim() else if (cats.isNotEmpty()) "Budget" else "Total spending" }
            val b = Budget(old?.id ?: uid(), n, a, cats, kw.trim())
            st.up { s -> s.copy(bl = if (old != null) s.bl.map { x -> if (x.id == old.id) b else x } else s.bl + b) }
            onClose()
        }
    }, onDelete = old?.let { o -> { st.up { s -> s.copy(bl = s.bl.filter { it.id != o.id }) }; onClose() } }) {
        Field(name, { name = it }, "Name (optional)")
        Field(amt, { amt = it }, "Monthly limit (${d.cur})", number = true)
        Muted("Counts spending from (none selected = all expenses)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            d.expCats.forEach { k -> Chip(catEmoji(k) + " " + k, k in cats, { cats = if (k in cats) cats - k else cats + k }) }
        }
        Field(kw, { kw = it }, "Only notes containing (optional)")
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecDialog(st: Store, old: Rec?, onClose: () -> Unit) {
    val d = st.d
    var type by remember { mutableStateOf(old?.type ?: "exp") }
    var name by remember { mutableStateOf(old?.note ?: "") }
    var amt by remember { mutableStateOf(old?.amt?.let { numText(it) } ?: "") }
    var cat by remember { mutableStateOf(old?.cat ?: "") }
    var acc by remember { mutableStateOf(old?.acc ?: d.accts.firstOrNull().orEmpty()) }
    var freq by remember { mutableStateOf(old?.freq ?: "m") }
    var next by remember { mutableStateOf(old?.next ?: today()) }
    val cats = if (type == "exp") d.expCats else d.incCats
    val curCat = if (cat in cats) cat else (cats.firstOrNull { it == "Other" } ?: cats.firstOrNull() ?: "")
    FormDialog(if (old == null) "New recurring" else "Edit recurring", onClose, onSave = {
        val a = parseAmt(amt)
        if (name.isNotBlank() && a != null && a > 0) {
            val r = Rec(old?.id ?: uid(), type, a, curCat, acc, name.trim(), freq, next)
            st.up { s -> s.copy(rec = if (old != null) s.rec.map { x -> if (x.id == old.id) r else x } else s.rec + r) }
            onClose()
        }
    }, onDelete = old?.let { o -> { st.up { s -> s.copy(rec = s.rec.filter { it.id != o.id }) }; onClose() } }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Expense", type == "exp", { type = "exp" }, Modifier.weight(1f))
            Chip("Income", type == "inc", { type = "inc" }, Modifier.weight(1f))
        }
        Field(name, { name = it }, "Name (rent, Netflix, salary…)")
        Field(amt, { amt = it }, "Amount (${d.cur})", number = true)
        Muted("Category")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            cats.forEach { k -> Chip(catEmoji(k) + " " + k, k == curCat, { cat = k }) }
        }
        Muted("Money place")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            d.accts.forEach { a -> Chip(accEmoji(a) + " " + a, a == acc, { acc = a }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Monthly", freq == "m", { freq = "m" }, Modifier.weight(1f))
            Chip("Weekly", freq == "w", { freq = "w" }, Modifier.weight(1f))
        }
        DateField(next, "Next due") { next = it }
    }
}

@Composable
fun TransferDialog(st: Store, onClose: () -> Unit) {
    val d = st.d
    var from by remember { mutableStateOf(d.accts.getOrNull(0).orEmpty()) }
    var to by remember { mutableStateOf(d.accts.getOrNull(1).orEmpty()) }
    var amt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today()) }
    FormDialog("Transfer", onClose, onSave = {
        val a = parseAmt(amt)
        if (a != null && a > 0 && from != to && from.isNotEmpty() && to.isNotEmpty()) {
            st.up { s -> s.copy(xf = s.xf + Xf(uid(), from, to, a, date, note.trim())) }
            onClose()
        }
    }) {
        Muted("From")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { d.accts.forEach { a -> Chip(a, a == from, { from = a }) } }
        Muted("To")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { d.accts.forEach { a -> Chip(a, a == to, { to = a }) } }
        Field(amt, { amt = it }, "Amount (${d.cur})", number = true)
        Field(note, { note = it }, "Note (optional)")
        DateField(date, "Date") { date = it }
    }
}

@Composable
fun GoalDialog(st: Store, onClose: () -> Unit) {
    val d = st.d
    var name by remember { mutableStateOf("") }
    var goal by remember { mutableStateOf("") }
    FormDialog("New goal", onClose, onSave = {
        val g = parseAmt(goal)
        if (name.isNotBlank() && g != null && g > 0) {
            st.up { s -> s.copy(sv = s.sv + Goal(uid(), name.trim(), g)) }
            onClose()
        }
    }) {
        Field(name, { name = it }, "Goal name")
        Field(goal, { goal = it }, "Target (${d.cur})", number = true)
    }
}

/** Add to / take out from a savings goal. dir = +1 or -1. */
@Composable
fun MoveDialog(st: Store, g: Goal, dir: Int, onClose: () -> Unit) {
    var amt by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    FormDialog(if (dir > 0) "Add to saving" else "Take out from saving", onClose, onSave = {
        val a = parseAmt(amt)
        if (a == null || a <= 0) { err = "Enter an amount" }
        else if (dir < 0 && a > g.saved) { err = "Not enough saved" }
        else {
            st.up { s -> s.copy(sv = s.sv.map { x -> if (x.id == g.id) x.copy(saved = x.saved + dir * a, hist = x.hist + Hist(today(), dir * a)) else x }) }
            onClose()
        }
    }) {
        Field(amt, { amt = it }, "Amount", number = true)
        if (err.isNotEmpty()) Text(err, color = Red)
    }
}

package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Bottom sheet for a new / edited transaction, or a transfer.
 * editId = transaction id to edit, or null. startXf = open on the Transfer tab.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TxSheet(st: Store, editId: String?, startXf: Boolean, onClose: () -> Unit) {
    val d = st.d
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = MaterialTheme.colorScheme
    val old = remember(editId) { d.tx.find { it.id == editId } }

    var mode by remember { mutableStateOf(if (old != null) (if (old.type == "inc") 1 else 0) else if (startXf) 2 else 0) }
    var amt by remember { mutableStateOf(old?.amt?.let { numText(it) } ?: "") }
    var name by remember { mutableStateOf(old?.note ?: "") }
    var cat by remember { mutableStateOf(old?.cat ?: "") }
    var acc by remember { mutableStateOf(old?.acc ?: d.accts.firstOrNull().orEmpty()) }
    var toAcc by remember { mutableStateOf(d.accts.firstOrNull { it != (old?.acc ?: d.accts.firstOrNull()) }.orEmpty()) }
    var date by remember { mutableStateOf(old?.date ?: today()) }
    var rc by remember { mutableStateOf(old?.rc ?: "") }
    var manual by remember { mutableStateOf(old != null) }
    var scanning by remember { mutableStateOf(false) }
    var chooser by remember { mutableStateOf(false) }
    var newCat by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("") }

    val type = if (mode == 1) "inc" else "exp"
    val cats = if (type == "exp") d.expCats else d.incCats
    val curCat = if (cat in cats) cat else (cats.firstOrNull { it == "Other" } ?: cats.firstOrNull() ?: "")

    fun process(uri: Uri) {
        scanning = true
        hint = ""
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { loadBitmap(ctx, uri, 1800) }.getOrNull() }
            if (bmp == null) {
                scanning = false
                hint = "Could not read the photo."
                return@launch
            }
            rc = withContext(Dispatchers.IO) { saveReceipt(ctx, bmp) }
            recognize(bmp, { text ->
                val r = parseReceipt(text)
                if (r.amt > 0) { mode = 0; amt = numText(r.amt) }
                if (r.date.isNotEmpty()) date = r.date
                if (r.name.isNotEmpty() && name.isBlank()) {
                    name = r.name
                    guessCat(r.name)?.let { g -> mode = if (g.first == "inc") 1 else 0; cat = g.second }
                }
                hint = if (r.amt > 0) "Scanned ${money(d.cur, r.amt)}. Check the details, then save."
                else "Couldn't find the total. Please fill it in."
                scanning = false
            }, {
                scanning = false
                hint = "Couldn't read text from the photo. Fill in manually."
            })
        }
    }

    val camUri = remember {
        val dir = File(ctx.cacheDir, "cam").apply { mkdirs() }
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(dir, "cap.jpg"))
    }
    val camLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) process(camUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) process(uri) }

    BackHandler { onClose() }

    val none = remember { MutableInteractionSource() }
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.93f).dp

    Box(
        Modifier.fillMaxSize().background(Color(0x77000000)).statusBarsPadding()
            .clickable(interactionSource = none, indication = null) { onClose() }
    ) {
        Surface(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = maxH)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
            shape = RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp), color = c.background
        ) {
            Column(Modifier.imePadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (old != null) "Edit transaction" else if (mode == 2) "New transfer" else "New transaction",
                        fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, modifier = Modifier.weight(1f)
                    )
                    if (mode != 2) Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(c.primary.copy(alpha = 0.14f)).clickable { chooser = true },
                        contentAlignment = Alignment.Center
                    ) { CameraIcon(c.primary, 28.dp) }
                }
                Spacer(Modifier.height(14.dp))
                Segmented(if (old != null) listOf("Expenses", "Income") else listOf("Expenses", "Income", "Transfer"), mode, { mode = it; if (it != 2) { manual = false } })
                if (hint.isNotEmpty()) Muted(hint, Modifier.padding(top = 10.dp), 14)

                Spacer(Modifier.height(18.dp))
                SmallLabel("Amount")
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(c.primary.copy(alpha = 0.07f))
                        .border(2.dp, c.primary, RoundedCornerShape(28.dp)).padding(horizontal = 22.dp, vertical = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(d.cur, color = c.primary, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Spacer(Modifier.width(14.dp))
                    Box(Modifier.weight(1f)) {
                        if (amt.isEmpty()) Text("0", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = c.onSurfaceVariant)
                        BasicTextField(
                            value = amt, onValueChange = { amt = it }, singleLine = true,
                            textStyle = TextStyle(color = c.onSurface, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, fontFamily = MaterialTheme.typography.bodyLarge.fontFamily),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(c.primary),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(10000, 25000, 50000, 100000).forEach { n ->
                        Text(
                            "+" + String.format(java.util.Locale.US, "%,d", n), color = c.primary, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                            modifier = Modifier.clip(RoundedCornerShape(22.dp)).background(c.primary.copy(alpha = 0.12f))
                                .clickable { amt = numText((parseAmt(amt) ?: 0.0) + n) }.padding(horizontal = 18.dp, vertical = 12.dp)
                        )
                    }
                    Text(
                        "Clear", color = c.onSurfaceVariant, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                        modifier = Modifier.clip(RoundedCornerShape(22.dp)).background(c.surfaceVariant)
                            .clickable { amt = "" }.padding(horizontal = 18.dp, vertical = 12.dp)
                    )
                }

                if (mode == 2) {
                    Spacer(Modifier.height(18.dp)); SmallLabel("From")
                    Spacer(Modifier.height(8.dp))
                    Dropdown(acc, d.accts.map { it to it }, { acc = it })
                    Spacer(Modifier.height(18.dp)); SmallLabel("To")
                    Spacer(Modifier.height(8.dp))
                    Dropdown(toAcc.ifEmpty { "Choose" }, d.accts.map { it to it }, { toAcc = it })
                    Spacer(Modifier.height(18.dp)); SmallLabel("Note")
                    Spacer(Modifier.height(8.dp))
                    PillField(name, { name = it }, "Optional")
                } else {
                    Spacer(Modifier.height(18.dp)); SmallLabel("Item name")
                    Spacer(Modifier.height(8.dp))
                    PillField(name, {
                        name = it
                        if (!manual) guessCat(it)?.let { g -> mode = if (g.first == "inc") 1 else 0; cat = g.second }
                    }, if (type == "exp") "e.g. Lunch, Taxi, Salary" else "e.g. Salary, Gift")
                    Spacer(Modifier.height(18.dp)); SmallLabel("Category")
                    Spacer(Modifier.height(8.dp))
                    (cats + "__new").chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { k ->
                                val on = k == curCat
                                Column(
                                    Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                                        .background(if (on) c.primary.copy(alpha = 0.12f) else c.surface)
                                        .border(if (on) 2.dp else 1.dp, if (on) c.primary else c.outline, RoundedCornerShape(24.dp))
                                        .clickable { if (k == "__new") newCat = true else { cat = k; manual = true } }
                                        .padding(vertical = 14.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Ico(if (k == "__new") "add" else catIcon(k), 42.dp)
                                    Spacer(Modifier.height(6.dp))
                                    Text(if (k == "__new") "New" else k, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    Spacer(Modifier.height(8.dp)); SmallLabel("Money place")
                    Spacer(Modifier.height(8.dp))
                    Dropdown(acc, d.accts.map { it to it }, { acc = it })
                }

                Spacer(Modifier.height(18.dp)); SmallLabel("Date")
                Spacer(Modifier.height(8.dp))
                DateField(date, "Date", { date = it })

                if (mode != 2 && rc.isNotEmpty() && File(rc).exists()) {
                    val bmp = remember(rc) { android.graphics.BitmapFactory.decodeFile(rc)?.asImageBitmap() }
                    if (bmp != null) {
                        Spacer(Modifier.height(16.dp)); SmallLabel("Receipt")
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(bmp, "Receipt", Modifier.size(84.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(12.dp))
                            TextButton(onClick = { rc = "" }) { Text("Remove receipt", color = Red) }
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        val a = parseAmt(amt)
                        if (a == null || a <= 0) { hint = "Enter a valid amount."; return@Button }
                        if (mode == 2) {
                            if (acc.isEmpty() || toAcc.isEmpty() || acc == toAcc) { hint = "Choose two different money places."; return@Button }
                            st.up { s -> s.copy(xf = s.xf + Xf(uid(), acc, toAcc, a, date, name.trim())) }
                        } else {
                            val t = Tx(old?.id ?: uid(), type, a, curCat, acc, date, name.trim(), rc)
                            st.up { s -> s.copy(tx = if (old != null) s.tx.map { x -> if (x.id == old.id) t else x } else s.tx + t) }
                        }
                        onClose()
                    },
                    modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(29.dp)
                ) { Text("Save", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
            }
        }
    }

    if (chooser) AlertDialog(
        onDismissRequest = { chooser = false },
        title = { Text("Scan receipt") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted("The amount, date and name are filled in automatically.", size = 14)
                Button(onClick = {
                    chooser = false
                    runCatching { File(ctx.cacheDir, "cam/cap.jpg").also { it.parentFile?.mkdirs(); it.createNewFile() } }
                    camLauncher.launch(camUri)
                }, Modifier.fillMaxWidth()) { Text("Take a photo") }
                OutlinedButton(onClick = {
                    chooser = false
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, Modifier.fillMaxWidth()) { Text("Choose from gallery") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { chooser = false }) { Text("Cancel") } }
    )
    if (scanning) AlertDialog(
        onDismissRequest = {}, confirmButton = {},
        title = { Text("Reading receipt…") },
        text = { LinearProgressIndicator(Modifier.fillMaxWidth()) }
    )
    if (newCat) {
        var n by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newCat = false },
            title = { Text("New category") },
            text = { Field(n, { n = it }, "Name") },
            confirmButton = {
                TextButton(onClick = {
                    val v = n.trim()
                    if (v.isNotEmpty()) {
                        st.up { s -> if (type == "exp") s.copy(expCats = if (v in s.expCats) s.expCats else s.expCats + v) else s.copy(incCats = if (v in s.incCats) s.incCats else s.incCats + v) }
                        cat = v; manual = true
                    }
                    newCat = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { newCat = false }) { Text("Cancel") } }
        )
    }
}

package com.mywallet.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.util.Locale
import java.util.UUID

data class Tx(
    val id: String, val type: String, val amt: Double, val cat: String,
    val acc: String, val date: String, val note: String, val rc: String = ""
)
data class Hist(val d: String, val a: Double)
data class Goal(val id: String, val name: String, val goal: Double, val saved: Double = 0.0, val hist: List<Hist> = emptyList())
data class Budget(val id: String, val name: String, val amt: Double, val cats: List<String>, val kw: String)
data class Rec(
    val id: String, val type: String, val amt: Double, val cat: String,
    val acc: String, val note: String, val freq: String, val next: String
)
data class Xf(val id: String, val from: String, val to: String, val amt: Double, val date: String, val note: String)

data class Data(
    val name: String = "",
    val onboarded: Boolean = false,
    val cur: String = "IDR",
    val limit: Double = 0.0,
    val theme: String = "auto",
    val accent: Int = 0,
    val accts: List<String> = listOf("Bank", "E-wallet", "Cash"),
    val open: Map<String, Double> = emptyMap(),
    val expCats: List<String> = listOf(
        "Food", "Transport", "Shopping", "Bills", "Health", "Fun", "Other",
        "Groceries", "Education", "Travel", "Pets", "Gifts"
    ),
    val incCats: List<String> = listOf("Salary", "Gift", "Other"),
    val tx: List<Tx> = emptyList(),
    val sv: List<Goal> = emptyList(),
    val bl: List<Budget> = emptyList(),
    val rec: List<Rec> = emptyList(),
    val xf: List<Xf> = emptyList()
)

fun uid(): String = UUID.randomUUID().toString().take(8)
fun today(): String = LocalDate.now().toString()

fun money(cur: String, v: Double): String {
    val s = if (Math.abs(v - Math.rint(v)) < 0.005) String.format(Locale.US, "%,.0f", v)
    else String.format(Locale.US, "%,.2f", v)
    return "$cur $s"
}

fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

fun Data.bal(acc: String): Double {
    var b = open[acc] ?: 0.0
    for (t in tx) if (t.acc == acc) b += if (t.type == "inc") t.amt else -t.amt
    for (x in xf) {
        if (x.from == acc) b -= x.amt
        if (x.to == acc) b += x.amt
    }
    return b
}

fun Data.total(): Double = accts.sumOf { bal(it) }

fun Data.spent(b: Budget, ym: String): Double = tx.filter {
    it.type == "exp" && it.date.startsWith(ym) &&
        (b.cats.isEmpty() || it.cat in b.cats) &&
        (b.kw.isBlank() || it.note.lowercase().contains(b.kw.lowercase()))
}.sumOf { it.amt }

fun nextDue(r: Rec): String {
    val d = LocalDate.parse(r.next)
    return (if (r.freq == "w") d.plusWeeks(1) else d.plusMonths(1)).toString()
}

/* ---------- JSON ---------- */

private fun JSONArray.strs(): List<String> = List(length()) { getString(it) }
private fun <T> JSONArray.objs(f: (JSONObject) -> T): List<T> = List(length()) { f(getJSONObject(it)) }

fun Data.toJson(): JSONObject {
    val o = JSONObject()
    o.put("name", name); o.put("onboarded", onboarded); o.put("cur", cur); o.put("limit", limit)
    o.put("theme", theme); o.put("accent", accent)
    o.put("accts", JSONArray(accts)); o.put("expCats", JSONArray(expCats)); o.put("incCats", JSONArray(incCats))
    val op = JSONObject(); open.forEach { (k, v) -> op.put(k, v) }; o.put("open", op)
    o.put("tx", JSONArray().also { a -> tx.forEach { a.put(JSONObject().put("id", it.id).put("type", it.type).put("amt", it.amt).put("cat", it.cat).put("acc", it.acc).put("date", it.date).put("note", it.note).put("rc", it.rc)) } })
    o.put("sv", JSONArray().also { a -> sv.forEach { g -> a.put(JSONObject().put("id", g.id).put("name", g.name).put("goal", g.goal).put("saved", g.saved).put("hist", JSONArray().also { h -> g.hist.forEach { x -> h.put(JSONObject().put("d", x.d).put("a", x.a)) } })) } })
    o.put("bl", JSONArray().also { a -> bl.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("amt", it.amt).put("cats", JSONArray(it.cats)).put("kw", it.kw)) } })
    o.put("rec", JSONArray().also { a -> rec.forEach { a.put(JSONObject().put("id", it.id).put("type", it.type).put("amt", it.amt).put("cat", it.cat).put("acc", it.acc).put("note", it.note).put("freq", it.freq).put("next", it.next)) } })
    o.put("xf", JSONArray().also { a -> xf.forEach { a.put(JSONObject().put("id", it.id).put("from", it.from).put("to", it.to).put("amt", it.amt).put("date", it.date).put("note", it.note)) } })
    return o
}

fun dataFromJson(o: JSONObject): Data {
    val def = Data()
    val op = o.optJSONObject("open")
    val open = HashMap<String, Double>()
    op?.keys()?.forEach { k -> open[k] = op.optDouble(k, 0.0) }
    return Data(
        name = o.optString("name", ""),
        onboarded = o.optBoolean("onboarded", false),
        cur = o.optString("cur", def.cur),
        limit = o.optDouble("limit", 0.0),
        theme = o.optString("theme", "auto"),
        accent = o.optInt("accent", 0),
        accts = o.optJSONArray("accts")?.strs() ?: def.accts,
        open = open,
        expCats = o.optJSONArray("expCats")?.strs() ?: def.expCats,
        incCats = o.optJSONArray("incCats")?.strs() ?: def.incCats,
        tx = o.optJSONArray("tx")?.objs { Tx(it.optString("id", uid()), it.optString("type", "exp"), it.optDouble("amt", 0.0), it.optString("cat", "Other"), it.optString("acc", ""), it.optString("date", today()), it.optString("note", ""), it.optString("rc", "")) } ?: emptyList(),
        sv = o.optJSONArray("sv")?.objs { g -> Goal(g.optString("id", uid()), g.optString("name", ""), g.optDouble("goal", 0.0), g.optDouble("saved", 0.0), g.optJSONArray("hist")?.objs { Hist(it.optString("d", ""), it.optDouble("a", 0.0)) } ?: emptyList()) } ?: emptyList(),
        bl = o.optJSONArray("bl")?.objs { Budget(it.optString("id", uid()), it.optString("name", ""), it.optDouble("amt", 0.0), it.optJSONArray("cats")?.strs() ?: emptyList(), it.optString("kw", "")) } ?: emptyList(),
        rec = o.optJSONArray("rec")?.objs { Rec(it.optString("id", uid()), it.optString("type", "exp"), it.optDouble("amt", 0.0), it.optString("cat", "Other"), it.optString("acc", ""), it.optString("note", ""), it.optString("freq", "m"), it.optString("next", today())) } ?: emptyList(),
        xf = o.optJSONArray("xf")?.objs { Xf(it.optString("id", uid()), it.optString("from", ""), it.optString("to", ""), it.optDouble("amt", 0.0), it.optString("date", today()), it.optString("note", "")) } ?: emptyList()
    )
}

/* ---------- Store (state holder, saved to a JSON file) ---------- */

class Store(app: Application) : AndroidViewModel(app) {
    private val file = File(app.filesDir, "data.json")

    var d by mutableStateOf(load())
        private set

    private fun load(): Data = try {
        if (file.exists()) dataFromJson(JSONObject(file.readText())) else Data()
    } catch (e: Exception) {
        Data()
    }

    fun up(f: (Data) -> Data) {
        d = f(d)
        try { file.writeText(d.toJson().toString()) } catch (_: Exception) { }
    }
}

/* ---------- Category helpers ---------- */

fun catEmoji(c: String): String = when (c) {
    "Food" -> "🍔"; "Transport" -> "🚌"; "Shopping" -> "🛍️"; "Bills" -> "🧾"; "Health" -> "💊"
    "Fun" -> "🎮"; "Other" -> "✨"; "Groceries" -> "🛒"; "Education" -> "📚"; "Travel" -> "✈️"
    "Pets" -> "🐾"; "Gifts", "Gift" -> "🎁"; "Salary" -> "💰"
    else -> "🏷️"
}

fun accEmoji(a: String): String = when (a) {
    "Bank" -> "🏦"; "Cash" -> "💵"; "E-wallet" -> "📱"; else -> "👛"
}

private val GUESS = listOf(
    "Salary" to listOf("salary", "gaji", "payroll"),
    "Groceries" to listOf("grocery", "groceries", "market", "mart", "alfa", "indomaret", "supermarket", "sembako", "hypermart"),
    "Food" to listOf("food", "lunch", "dinner", "breakfast", "makan", "nasi", "kopi", "coffee", "cafe", "resto", "restaurant", "burger", "pizza", "bakery", "warung", "kfc", "mcd"),
    "Transport" to listOf("grab", "gojek", "taxi", "bensin", "fuel", "parkir", "parking", "ojek", "bus", "toll", "tol", "pertamina", "shell"),
    "Bills" to listOf("listrik", "pln", "wifi", "internet", "pulsa", "bill", "tagihan", "netflix", "spotify"),
    "Health" to listOf("apotek", "pharmacy", "dokter", "doctor", "clinic", "klinik", "hospital", "kimia farma"),
    "Shopping" to listOf("shop", "toko", "mall", "store", "fashion")
)

/** Returns (type, category) for a note, or null if nothing matches. */
fun guessCat(note: String): Pair<String, String>? {
    val n = note.lowercase()
    for ((cat, words) in GUESS) if (words.any { n.contains(it) }) return (if (cat == "Salary") "inc" else "exp") to cat
    return null
}

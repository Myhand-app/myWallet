package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/* ============================== HOME ============================== */

@Composable
fun HomeScreen(st: Store, onOpen: (String) -> Unit) {
    val d = st.d
    val c = MaterialTheme.colorScheme
    var q by remember { mutableStateOf("") }
    var typeF by remember { mutableStateOf("all") }
    var accF by remember { mutableStateOf("") }
    var budNew by remember { mutableStateOf(false) }
    var budEdit by remember { mutableStateOf<Budget?>(null) }
    var recNew by remember { mutableStateOf(false) }
    var recEdit by remember { mutableStateOf<Rec?>(null) }
    var xfOpen by remember { mutableStateOf(false) }
    var balEdit by remember { mutableStateOf<String?>(null) }

    val td = today()
    val ym = td.take(7)
    val month = d.tx.filter { it.date.startsWith(ym) }
    val inc = month.filter { it.type == "inc" }.sumOf { it.amt }
    val exp = month.filter { it.type == "exp" }.sumOf { it.amt }
    val spentToday = d.tx.filter { it.type == "exp" && it.date == td }.sumOf { it.amt }
    val list = d.tx.filter {
        (typeF == "all" || it.type == typeF) && (accF.isEmpty() || it.acc == accF) &&
            (q.isBlank() || (it.note + " " + it.cat).contains(q, ignoreCase = true))
    }.sortedByDescending { it.date }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(c.primary, lerp(c.primary, Color(0xFFFF6EC7), 0.5f))))
                    .padding(20.dp)
            ) {
                Column {
                    Text("Total balance", color = Color.White.copy(alpha = 0.9f), fontWeight = FontWeight.SemiBold)
                    Text(money(d.cur, d.total()), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 6.dp))
                    Row {
                        Column(Modifier.weight(1f)) {
                            Text("Income this month", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            Text(money(d.cur, inc), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Expenses this month", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            Text(money(d.cur, exp), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily limit", fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    if (d.limit > 0) Muted("${money(d.cur, spentToday)} / ${money(d.cur, d.limit)}")
                    else Muted("Set in Settings", size = 14)
                }
                if (d.limit > 0) {
                    val p = (spentToday / d.limit).toFloat()
                    Spacer(Modifier.height(8.dp))
                    Bar(p, barColor(p))
                }
            }
        }
        item {
            AppCard {
                SectionRow("Budgets", "+ Add") { budNew = true }
                if (d.bl.isEmpty()) Muted("Add a monthly budget for one category, several categories, a keyword (like “netflix”) or all spending.", Modifier.padding(top = 6.dp), 14)
                d.bl.forEach { b ->
                    val sp = d.spent(b, ym)
                    val p = if (b.amt > 0) (sp / b.amt).toFloat() else 0f
                    Column(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(10.dp)).clickable { budEdit = b }) {
                        Row {
                            Text(b.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Muted(money(d.cur, sp) + " / " + money(d.cur, b.amt) + (if (p >= 1f) " · over" else if (p >= 0.8f) " · ${(p * 100).toInt()}%" else ""))
                        }
                        Spacer(Modifier.height(6.dp))
                        Bar(p, barColor(p))
                    }
                }
            }
        }
        item {
            AppCard {
                SectionRow("Recurring & bills", "+ Add") { recNew = true }
                if (d.rec.isEmpty()) Muted("Add rent, subscriptions or salary and get an \"Add\" button when they are due.", Modifier.padding(top = 6.dp), 14)
                d.rec.forEach { r ->
                    val due = r.next <= td
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(10.dp)).clickable { recEdit = r },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(r.note, fontWeight = FontWeight.Bold)
                            Muted((if (r.type == "inc") "+" else "-") + money(d.cur, r.amt) + " · " + (if (r.freq == "w") "weekly" else "monthly") + " · due " + r.next)
                        }
                        if (due) Button(onClick = {
                            st.up { s ->
                                val acc = if (r.acc in s.accts) r.acc else s.accts.firstOrNull().orEmpty()
                                s.copy(
                                    tx = s.tx + Tx(uid(), r.type, r.amt, r.cat, acc, r.next, r.note),
                                    rec = s.rec.map { x -> if (x.id == r.id) x.copy(next = nextDue(x)) else x }
                                )
                            }
                        }, shape = RoundedCornerShape(12.dp)) { Text("Add") }
                    }
                }
            }
        }
        item { SectionRow("Money places", "Transfer") { xfOpen = true } }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(d.accts) { a ->
                    Surface(
                        Modifier.width(140.dp).clip(RoundedCornerShape(22.dp)).clickable { balEdit = a },
                        shape = RoundedCornerShape(22.dp), color = c.surface, shadowElevation = 2.dp
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(c.primary.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) { Text(accEmoji(a), fontSize = 20.sp) }
                            Spacer(Modifier.height(8.dp))
                            Muted(a)
                            Text(money(d.cur, d.bal(a)), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
        item { Text("Transactions", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { Field(q, { q = it }, "Search…") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("All", typeF == "all", { typeF = "all" }) }
                item { Chip("Expenses", typeF == "exp", { typeF = "exp" }) }
                item { Chip("Income", typeF == "inc", { typeF = "inc" }) }
                item { Chip("Any place", accF.isEmpty(), { accF = "" }) }
                items(d.accts) { a -> Chip(a, accF == a, { accF = if (accF == a) "" else a }) }
            }
        }
        if (list.isEmpty()) item { Muted("No transactions yet. Tap ✏️ to add one.", Modifier.padding(8.dp), 14) }
        items(list.take(200), key = { it.id }) { x -> TxRow(x, d.cur) { onOpen(x.id) } }
    }

    if (budNew) BudgetDialog(st, null) { budNew = false }
    budEdit?.let { b -> BudgetDialog(st, b) { budEdit = null } }
    if (recNew) RecDialog(st, null) { recNew = false }
    recEdit?.let { r -> RecDialog(st, r) { recEdit = null } }
    if (xfOpen) TransferDialog(st) { xfOpen = false }
    balEdit?.let { a ->
        var v by remember(a) { mutableStateOf(numText(d.open[a] ?: 0.0)) }
        AlertDialog(
            onDismissRequest = { balEdit = null },
            title = { Text("$a starting balance") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Muted("Money you already had here before using the app. Current: ${money(d.cur, d.bal(a))}", size = 14)
                    Field(v, { v = it }, "Starting balance (${d.cur})", number = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = v.trim().replace(',', '.').toDoubleOrNull()
                    if (n != null) st.up { s -> s.copy(open = s.open + (a to n)) }
                    balEdit = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { balEdit = null }) { Text("Cancel") } }
        )
    }
}

/* ============================== SAVING ============================== */

@Composable
fun SavingScreen(st: Store) {
    val d = st.d
    var newGoal by remember { mutableStateOf(false) }
    var move by remember { mutableStateOf<Pair<Goal, Int>?>(null) }
    var hist by remember { mutableStateOf<Goal?>(null) }
    var del by remember { mutableStateOf<Goal?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionRow("Saving goals", "+ New goal") { newGoal = true } }
        if (d.sv.isEmpty()) item { Muted("No goals yet. Create one and watch it grow.", Modifier.padding(8.dp), 14) }
        items(d.sv, key = { it.id }) { g ->
            val p = if (g.goal > 0) (g.saved / g.goal).toFloat() else 0f
            AppCard {
                Row {
                    Text(g.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Text("${(p * 100).toInt()}%", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Muted("${money(d.cur, g.saved)} of ${money(d.cur, g.goal)}", Modifier.padding(vertical = 6.dp), 14)
                Bar(p, if (p >= 1f) Green else MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { move = g to 1 }, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Add") }
                    OutlinedButton(onClick = { move = g to -1 }, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Take out") }
                    TextButton(onClick = { hist = g }) { Text("History") }
                    TextButton(onClick = { del = g }) { Text("Delete", color = Red) }
                }
            }
        }
    }
    if (newGoal) GoalDialog(st) { newGoal = false }
    move?.let { (g, dir) -> MoveDialog(st, g, dir) { move = null } }
    hist?.let { g ->
        AlertDialog(
            onDismissRequest = { hist = null }, confirmButton = { TextButton(onClick = { hist = null }) { Text("Close") } },
            title = { Text(g.name + " history") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (g.hist.isEmpty()) Muted("Nothing yet.", size = 14)
                    g.hist.reversed().forEach { h ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(h.d, Modifier.weight(1f))
                            Text((if (h.a > 0) "+" else "-") + money(d.cur, Math.abs(h.a)), color = if (h.a > 0) Green else Red, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        )
    }
    del?.let { g ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("Delete ${g.name}?") },
            confirmButton = { TextButton(onClick = { st.up { s -> s.copy(sv = s.sv.filter { it.id != g.id }) }; del = null }) { Text("Delete", color = Red) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel") } }
        )
    }
}

/* ============================== REPORTS ============================== */

@Composable
fun ReportsScreen(st: Store, onOpen: (String) -> Unit) {
    val d = st.d
    var mode by remember { mutableStateOf(2) } // 0 day, 1 week, 2 month, 3 year
    var off by remember { mutableStateOf(0) }

    val now = LocalDate.now()
    val (a, b) = when (mode) {
        0 -> now.plusDays(off.toLong()).let { it to it }
        1 -> now.plusWeeks(off.toLong()).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).let { it to it.plusDays(6) }
        2 -> now.plusMonths(off.toLong()).withDayOfMonth(1).let { it to it.plusMonths(1).minusDays(1) }
        else -> now.plusYears(off.toLong()).withDayOfYear(1).let { it to it.plusYears(1).minusDays(1) }
    }
    val label = when (mode) {
        0 -> a.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.US))
        1 -> a.format(DateTimeFormatter.ofPattern("d MMM", Locale.US)) + " – " + b.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US))
        2 -> a.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US))
        else -> a.year.toString()
    }
    val sa = a.toString()
    val sb = b.toString()
    val rows = d.tx.filter { it.date >= sa && it.date <= sb }.sortedByDescending { it.date }
    val inc = rows.filter { it.type == "inc" }.sumOf { it.amt }
    val exp = rows.filter { it.type == "exp" }.sumOf { it.amt }
    val byCat = rows.filter { it.type == "exp" }.groupBy { it.cat }.map { it.key to it.value.sumOf { x -> x.amt } }.sortedByDescending { it.second }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Day", "Week", "Month", "Year").forEachIndexed { i, s -> Chip(s, mode == i, { mode = i; off = 0 }) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("‹", fontSize = 28.sp, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { off-- }.padding(horizontal = 14.dp))
                Text(label, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                Text("›", fontSize = 28.sp, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { if (off < 0) off++ }.padding(horizontal = 14.dp))
            }
        }
        item {
            AppCard {
                Row {
                    Column(Modifier.weight(1f)) { Muted("Income"); Text(money(d.cur, inc), color = Green, fontWeight = FontWeight.ExtraBold) }
                    Column(Modifier.weight(1f)) { Muted("Expenses"); Text(money(d.cur, exp), color = Red, fontWeight = FontWeight.ExtraBold) }
                    Column(Modifier.weight(1f)) { Muted("Net"); Text(money(d.cur, inc - exp), fontWeight = FontWeight.ExtraBold) }
                }
            }
        }
        item {
            AppCard {
                Text("Spending by category", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (byCat.isEmpty()) Muted("No expenses in this period.", Modifier.padding(top = 6.dp), 14)
                byCat.forEach { (cat, v) ->
                    Column(Modifier.padding(top = 10.dp)) {
                        Row {
                            Text(catEmoji(cat) + " " + cat, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Muted(money(d.cur, v) + " · " + (if (exp > 0) (v / exp * 100).toInt() else 0) + "%")
                        }
                        Spacer(Modifier.height(5.dp))
                        Bar(if (exp > 0) (v / exp).toFloat() else 0f, MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item { Text("Transactions", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        if (rows.isEmpty()) item { Muted("Nothing in this period.", Modifier.padding(8.dp), 14) }
        items(rows.take(200), key = { it.id }) { x -> TxRow(x, d.cur) { onOpen(x.id) } }
    }
}

/* ============================== SETTINGS ============================== */

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(st: Store) {
    val d = st.d
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var newAcc by remember { mutableStateOf("") }
    var newExp by remember { mutableStateOf("") }
    var newInc by remember { mutableStateOf("") }
    var reset by remember { mutableStateOf(false) }

    val exportJson = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) msg = runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(d.toJson().toString(2).toByteArray()) }
            "Backup saved."
        }.getOrElse { "Could not save the backup." }
    }
    val exportCsv = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) msg = runCatching {
            val sb = StringBuilder("Date,Type,Category,Account,Item,Amount\n")
            fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            d.tx.sortedBy { it.date }.forEach { sb.append("${it.date},${it.type},${q(it.cat)},${q(it.acc)},${q(it.note)},${it.amt}\n") }
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(sb.toString().toByteArray()) }
            "CSV saved."
        }.getOrElse { "Could not save the CSV." }
    }
    val importer = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) msg = runCatching {
            val text = ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes()) }
            val nd = dataFromJson(org.json.JSONObject(text))
            st.up { nd.copy(onboarded = true) }
            "Backup restored."
        }.getOrElse { "That file is not a valid backup." }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AppCard {
                Text("Profile", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Field(d.name, { v -> st.up { it.copy(name = v) } }, "Your name")
            }
        }
        item {
            AppCard {
                Text("Appearance", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("auto" to "Auto", "light" to "Light", "dark" to "Dark").forEach { (k, l) ->
                        Chip(l, d.theme == k, { st.up { it.copy(theme = k) } })
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Accents.forEachIndexed { i, col ->
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(Color(col))
                                .border(if (d.accent == i) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                .clickable { st.up { it.copy(accent = i) } }
                        )
                    }
                }
            }
        }
        item {
            AppCard {
                Text("Currency & daily limit", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("IDR", "USD", "EUR", "GBP", "JPY", "SGD", "MYR", "AUD", "INR").forEach { k ->
                        Chip(k, d.cur == k, { st.up { it.copy(cur = k) } })
                    }
                }
                Spacer(Modifier.height(10.dp))
                var lim by remember { mutableStateOf(if (d.limit > 0) numText(d.limit) else "") }
                Field(lim, { v ->
                    lim = v
                    st.up { it.copy(limit = v.trim().replace(',', '.').toDoubleOrNull() ?: 0.0) }
                }, "Daily spending limit (0 = off)", number = true)
            }
        }
        item {
            AppCard {
                Text("Money places", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                d.accts.forEach { a ->
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(accEmoji(a) + " " + a, Modifier.weight(1f))
                        if (d.accts.size > 1) Text("Remove", color = Red, modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                            st.up { s -> s.copy(accts = s.accts - a) }
                        }.padding(8.dp))
                    }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Field(newAcc, { newAcc = it }, "New place", modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val n = newAcc.trim()
                        if (n.isNotEmpty() && n !in d.accts) st.up { it.copy(accts = it.accts + n) }
                        newAcc = ""
                    }) { Text("Add") }
                }
            }
        }
        item {
            AppCard {
                Text("Expense categories", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    d.expCats.forEach { k -> Chip(catEmoji(k) + " " + k + "  ✕", false, { st.up { s -> s.copy(expCats = s.expCats - k) } }) }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Field(newExp, { newExp = it }, "New category", modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val n = newExp.trim()
                        if (n.isNotEmpty() && n !in d.expCats) st.up { it.copy(expCats = it.expCats + n) }
                        newExp = ""
                    }) { Text("Add") }
                }
                Spacer(Modifier.height(14.dp))
                Text("Income categories", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    d.incCats.forEach { k -> Chip(catEmoji(k) + " " + k + "  ✕", false, { st.up { s -> s.copy(incCats = s.incCats - k) } }) }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Field(newInc, { newInc = it }, "New category", modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        val n = newInc.trim()
                        if (n.isNotEmpty() && n !in d.incCats) st.up { it.copy(incCats = it.incCats + n) }
                        newInc = ""
                    }) { Text("Add") }
                }
            }
        }
        item {
            AppCard {
                Text("Data", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Muted("Backups include transactions, goals, budgets and settings (not receipt photos).", Modifier.padding(vertical = 6.dp), 13)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exportJson.launch("mywallet-backup.json") }, shape = RoundedCornerShape(12.dp)) { Text("Backup") }
                    OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }, shape = RoundedCornerShape(12.dp)) { Text("Restore") }
                    OutlinedButton(onClick = { exportCsv.launch("mywallet.csv") }, shape = RoundedCornerShape(12.dp)) { Text("CSV") }
                }
                if (msg.isNotEmpty()) Muted(msg, Modifier.padding(top = 8.dp), 14)
                TextButton(onClick = { reset = true }) { Text("Reset all data", color = Red) }
            }
        }
    }
    if (reset) AlertDialog(
        onDismissRequest = { reset = false },
        title = { Text("Reset all data?") },
        text = { Text("This deletes every transaction, goal and setting on this device.") },
        confirmButton = { TextButton(onClick = { st.up { Data() }; reset = false }) { Text("Reset", color = Red) } },
        dismissButton = { TextButton(onClick = { reset = false }) { Text("Cancel") } }
    )
}

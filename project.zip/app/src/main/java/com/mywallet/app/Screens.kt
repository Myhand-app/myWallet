package com.mywallet.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/* ============================== HOME ============================== */

@Composable
fun HomeScreen(st: Store, onOpen: (String) -> Unit, onNew: (Boolean) -> Unit) {
    val d = st.d
    val c = MaterialTheme.colorScheme
    var q by remember { mutableStateOf("") }
    var typeF by remember { mutableStateOf("all") }
    var accF by remember { mutableStateOf("") }
    var budNew by remember { mutableStateOf(false) }
    var budEdit by remember { mutableStateOf<Budget?>(null) }
    var recNew by remember { mutableStateOf(false) }
    var recEdit by remember { mutableStateOf<Rec?>(null) }
    var hist by remember { mutableStateOf(false) }
    var balEdit by remember { mutableStateOf<String?>(null) }

    val td = today()
    val ym = td.take(7)
    val month = d.tx.filter { it.date.startsWith(ym) }
    val inc = month.filter { it.type == "inc" }.sumOf { it.amt }
    val exp = month.filter { it.type == "exp" }.sumOf { it.amt }
    val spentToday = d.tx.filter { it.type == "exp" && it.date == td }.sumOf { it.amt }
    val list = d.tx.filter {
        (typeF == "all" || it.type == typeF) && (accF.isEmpty() || it.acc == accF) &&
            (q.isBlank() || (it.note + " " + it.cat).contains(q, ignoreCase = true))
    }.sortedByDescending { it.date }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
                    .background(Brush.linearGradient(listOf(c.primary, lerp(c.primary, Color(0xFFFF6EC7), 0.5f))))
                    .drawBehind { drawCircle(Color.White.copy(alpha = 0.12f), radius = size.height * 0.62f, center = Offset(size.width * 0.9f, size.height * 0.05f)) }
                    .padding(22.dp)
            ) {
                Column {
                    Text("Total balance", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text(money(d.cur, d.total()), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 10.dp, bottom = 12.dp), letterSpacing = (-1).sp)
                    Row {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Ico("dn", 24.dp, tint = Color.White); Spacer(Modifier.width(6.dp)); Text("Income", color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp) }
                            Text(money(d.cur, inc), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Ico("up", 24.dp, tint = Color.White); Spacer(Modifier.width(6.dp)); Text("Expenses", color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp) }
                            Text(money(d.cur, exp), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        }
                    }
                }
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily limit", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    if (d.limit > 0) Muted("${money(d.cur, spentToday)} / ${money(d.cur, d.limit)}", size = 16)
                    else Muted("Set in Settings", size = 16)
                }
                if (d.limit > 0) {
                    val p = (spentToday / d.limit).toFloat()
                    Spacer(Modifier.height(12.dp))
                    Bar(p, barColor(p))
                }
            }
        }
        item {
            AppCard {
                SectionRow("Budgets", "+ Add") { budNew = true }
                if (d.bl.isEmpty()) Muted("Add a monthly budget for one category, several categories, a keyword (like “netflix”) or all spending.", Modifier.padding(top = 10.dp), 16)
                d.bl.forEach { b ->
                    val sp = d.spent(b, ym)
                    val p = if (b.amt > 0) (sp / b.amt).toFloat() else 0f
                    Column(Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(10.dp)).clickable { budEdit = b }) {
                        Row {
                            Text(b.name, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                            Muted(money(d.cur, sp) + " / " + money(d.cur, b.amt) + (if (p >= 1f) " · over" else if (p >= 0.8f) " · ${(p * 100).toInt()}%" else ""), size = 15)
                        }
                        Spacer(Modifier.height(8.dp))
                        Bar(p, barColor(p))
                        Muted(if (b.cats.isEmpty() && b.kw.isBlank()) "All spending" else (b.cats + listOfNotNull(b.kw.takeIf { it.isNotBlank() }?.let { "“$it”" })).joinToString(", "), Modifier.padding(top = 4.dp), 15)
                    }
                }
            }
        }
        item {
            AppCard {
                SectionRow("Recurring & bills", "+ Add") { recNew = true }
                if (d.rec.isEmpty()) Muted("Add rent, subscriptions or salary and get an \"Add\" button when they are due.", Modifier.padding(top = 10.dp), 16)
                d.rec.forEach { r ->
                    val due = r.next <= td
                    Row(
                        Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(10.dp)).clickable { recEdit = r },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(r.note, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            Muted((if (r.type == "inc") "+" else "−") + money(d.cur, r.amt) + " · " + (if (r.freq == "w") "weekly" else "monthly") + " · due " + r.next, size = 14)
                        }
                        if (due) Button(onClick = {
                            st.up { s ->
                                val acc = if (r.acc in s.accts) r.acc else s.accts.firstOrNull().orEmpty()
                                s.copy(
                                    tx = s.tx + Tx(uid(), r.type, r.amt, r.cat, acc, r.next, r.note),
                                    rec = s.rec.map { x -> if (x.id == r.id) x.copy(next = nextDue(x)) else x }
                                )
                            }
                        }, shape = RoundedCornerShape(14.dp)) { Text("Add") }
                    }
                }
            }
        }
        item { SectionRow("Money places", "History") { hist = true } }
        item {
            val perRow = if (d.accts.size <= 3) d.accts.size else 3
            if (d.accts.size <= 3) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                d.accts.forEach { a -> AccountCard(a, d, Modifier.weight(1f)) { balEdit = a } }
            } else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(d.accts) { a -> AccountCard(a, d, Modifier.width(150.dp)) { balEdit = a } }
            }
        }
        item { Text("Transactions", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
        item { PillField(q, { q = it }, "Search…") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Dropdown(
                    when (typeF) { "exp" -> "Expenses"; "inc" -> "Income"; else -> "All" },
                    listOf("all" to "All", "exp" to "Expenses", "inc" to "Income"), { typeF = it }, Modifier.weight(1f)
                )
                Dropdown(if (accF.isEmpty()) "Money places" else accF, listOf("" to "Money places") + d.accts.map { it to it }, { accF = it }, Modifier.weight(1f))
            }
        }
        item { TxList(list, d.cur, onOpen) }
    }

    if (budNew) BudgetDialog(st, null) { budNew = false }
    budEdit?.let { b -> BudgetDialog(st, b) { budEdit = null } }
    if (recNew) RecDialog(st, null) { recNew = false }
    recEdit?.let { r -> RecDialog(st, r) { recEdit = null } }
    if (hist) TransferHistory(st, { hist = false }, { hist = false; onNew(true) })
    balEdit?.let { a ->
        var v by remember(a) { mutableStateOf(numText(d.open[a] ?: 0.0)) }
        AlertDialog(
            onDismissRequest = { balEdit = null },
            title = { Text("$a starting balance") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Muted("Money you already had here before using the app. Current: ${money(d.cur, d.bal(a))}", size = 14)
                    Field(v, { v = it }, "Starting balance (${d.cur})", number = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = v.trim().replace(',', '.').toDoubleOrNull()
                    if (n != null) st.up { s -> s.copy(open = s.open + (a to n)) }
                    balEdit = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { balEdit = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun AccountCard(a: String, d: Data, modifier: Modifier, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Surface(
        modifier.clip(RoundedCornerShape(28.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp), color = c.surface, border = BorderStroke(1.dp, c.outline), shadowElevation = 3.dp
    ) {
        Column(Modifier.padding(16.dp)) {
            IconTile(accIcon(a), 52.dp, 34.dp)
            Spacer(Modifier.height(14.dp))
            Muted(a, size = 17)
            Text(money(d.cur, d.bal(a)), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun TransferHistory(st: Store, onClose: () -> Unit, onNew: () -> Unit) {
    val d = st.d
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Transfer history", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (d.xf.isEmpty()) Muted("No transfers yet", Modifier.padding(8.dp), 15)
                d.xf.sortedByDescending { it.date }.forEach { z ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Ico("swap", 30.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${z.from} → ${z.to}", fontWeight = FontWeight.Bold)
                            Muted(z.date + if (z.note.isNotBlank()) " · " + z.note else "")
                        }
                        Text(money(d.cur, z.amt), fontWeight = FontWeight.Bold)
                        Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable { st.up { s -> s.copy(xf = s.xf.filter { it.id != z.id }) } }.padding(6.dp)) { Ico("tr", 24.dp) }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onNew) { Text("New transfer", fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

/* ============================== SAVING ============================== */

@Composable
fun Plant(stage: Int, modifier: Modifier = Modifier) {
    val s = stage.coerceIn(1, 10)
    Canvas(modifier) {
        val k = minOf(size.width / 200f, size.height / 190f)
        val gy = size.height * 0.88f
        val cx = size.width / 2f
        drawOval(Color(0xFF8ED88F), Offset(cx - 95 * k, gy - 14 * k), Size(190 * k, 34 * k))
        drawOval(Color(0xFF66BB6A), Offset(cx - 62 * k, gy - 8 * k), Size(124 * k, 22 * k))
        drawOval(Color(0xFF8B5A3C), Offset(cx - 28 * k, gy - 12 * k), Size(56 * k, 18 * k))
        if (s == 1) {
            drawOval(Color(0xFF6B4A2B), Offset(cx - 6 * k, gy - 18 * k), Size(12 * k, 9 * k))
        } else {
            val hs = listOf(0f, 0f, 26f, 42f, 62f, 84f, 104f, 118f, 128f, 134f)
            val h = hs[s - 1] * k
            val top = gy - 4 * k - h
            val trunkW = (3 + maxOf(0, s - 5) * 1.6f) * k
            drawLine(if (s >= 6) Color(0xFF8B5A3C) else Color(0xFF3FAE62), Offset(cx, gy - 4 * k), Offset(cx, top), strokeWidth = trunkW, cap = StrokeCap.Round)
            val n = minOf(s, 6)
            for (i in 0 until n) {
                val y = gy - 4 * k - h * (0.25f + 0.65f * i / n)
                val right = i % 2 == 0
                drawOval(if (i % 2 == 0) Color(0xFF4CC38A) else Color(0xFF7BE3A2), Offset(if (right) cx else cx - 24 * k, y - 7 * k), Size(24 * k, 13 * k))
            }
            if (s >= 6) {
                val r = (18 + (s - 6) * 7) * k
                drawCircle(Color(0xFF4CC38A), r, Offset(cx - r * 0.55f, top))
                drawCircle(Color(0xFF4CC38A), r, Offset(cx + r * 0.55f, top))
                drawCircle(Color(0xFF7BE3A2), r * 1.05f, Offset(cx, top - r * 0.35f))
                if (s >= 9) listOf(-0.6f to 0.2f, 0.5f to -0.1f, 0f to -0.8f).forEach { (dx, dy) ->
                    drawCircle(Color(0xFFFF8FB8), 5 * k, Offset(cx + dx * r, top + dy * r))
                }
            }
        }
    }
}

@Composable
fun SavingScreen(st: Store) {
    val d = st.d
    val c = MaterialTheme.colorScheme
    var newGoal by remember { mutableStateOf(false) }
    var move by remember { mutableStateOf<Pair<Goal, Int>?>(null) }
    var hist by remember { mutableStateOf<Goal?>(null) }
    var del by remember { mutableStateOf<Goal?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (d.sv.isEmpty()) item {
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = c.surface, border = BorderStroke(1.dp, c.outline), shadowElevation = 3.dp) {
                Column {
                    Box(Modifier.fillMaxWidth().height(300.dp).background(Brush.verticalGradient(listOf(c.primary.copy(alpha = 0.22f), Color.Transparent)))) {
                        Plant(1, Modifier.fillMaxSize())
                    }
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                        Text("Plant your first goal", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        Muted("Save toward something you want and watch your tree grow through 10 stages.", Modifier.padding(top = 6.dp), 16)
                    }
                }
            }
        }
        items(d.sv, key = { it.id }) { g ->
            val p = if (g.goal > 0) (g.saved / g.goal).toFloat() else 0f
            val stage = if (g.saved <= 0) 1 else (2 + (p.coerceAtMost(1f) * 8).toInt()).coerceIn(2, 10)
            Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), color = c.surface, border = BorderStroke(1.dp, c.outline), shadowElevation = 3.dp) {
                Column {
                    Box(Modifier.fillMaxWidth().height(220.dp).background(Brush.verticalGradient(listOf(c.primary.copy(alpha = 0.22f), Color.Transparent)))) {
                        Plant(stage, Modifier.fillMaxSize())
                    }
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                        Row {
                            Text(g.name, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                            Text("${(p * 100).toInt()}%", fontWeight = FontWeight.ExtraBold, color = c.primary, fontSize = 18.sp)
                        }
                        Muted("${money(d.cur, g.saved)} of ${money(d.cur, g.goal)}", Modifier.padding(vertical = 6.dp), 15)
                        Bar(p, if (p >= 1f) Green else c.primary)
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { move = g to 1 }, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Add") }
                            OutlinedButton(onClick = { move = g to -1 }, shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(horizontal = 14.dp)) { Text("Take out") }
                            TextButton(onClick = { hist = g }) { Text("History") }
                            Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable { del = g }.padding(6.dp)) { Ico("tr", 26.dp) }
                        }
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(30.dp)).background(c.primary).clickable { newGoal = true },
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
            ) {
                Ico("pl", 30.dp)
                Spacer(Modifier.width(10.dp))
                Text("New saving goal", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
        }
    }
    if (newGoal) GoalDialog(st) { newGoal = false }
    move?.let { (g, dir) -> MoveDialog(st, g, dir) { move = null } }
    hist?.let { g ->
        AlertDialog(
            onDismissRequest = { hist = null }, confirmButton = { TextButton(onClick = { hist = null }) { Text("Close") } },
            title = { Text(g.name + " history") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (g.hist.isEmpty()) Muted("Nothing yet.", size = 14)
                    g.hist.reversed().forEach { h ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(h.d, Modifier.weight(1f))
                            Text((if (h.a > 0) "+" else "−") + money(d.cur, Math.abs(h.a)), color = if (h.a > 0) Green else Red, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        )
    }
    del?.let { g ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("Delete ${g.name}?") },
            confirmButton = { TextButton(onClick = { st.up { s -> s.copy(sv = s.sv.filter { it.id != g.id }) }; del = null }) { Text("Delete", color = Red) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel") } }
        )
    }
}

/* ============================== REPORTS ============================== */

@Composable
fun ReportsScreen(st: Store, onOpen: (String) -> Unit) {
    val d = st.d
    val c = MaterialTheme.colorScheme
    var mode by remember { mutableStateOf(0) } // 0 daily, 1 weekly, 2 monthly, 3 quarterly, 4 yearly
    var off by remember { mutableStateOf(0) }
    var tab by remember { mutableStateOf(0) } // 0 expenses, 1 income
    var catF by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var typeF by remember { mutableStateOf("all") }

    val now = LocalDate.now()
    val (a, b) = when (mode) {
        0 -> now.plusDays(off.toLong()).let { it to it }
        1 -> now.plusWeeks(off.toLong()).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).let { it to it.plusDays(6) }
        2 -> now.plusMonths(off.toLong()).withDayOfMonth(1).let { it to it.plusMonths(1).minusDays(1) }
        3 -> now.withDayOfMonth(1).minusMonths(((now.monthValue - 1) % 3).toLong()).plusMonths(3L * off).let { it to it.plusMonths(3).minusDays(1) }
        else -> now.plusYears(off.toLong()).withDayOfYear(1).let { it to it.plusYears(1).minusDays(1) }
    }
    val label = when (mode) {
        0 -> a.format(DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.US))
        1 -> a.format(DateTimeFormatter.ofPattern("d MMM", Locale.US)) + " – " + b.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US))
        2 -> a.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US))
        3 -> "Q" + ((a.monthValue - 1) / 3 + 1) + " " + a.year
        else -> a.year.toString()
    }
    val sa = a.toString()
    val sb = b.toString()
    val inRange = d.tx.filter { it.date >= sa && it.date <= sb }
    val inc = inRange.filter { it.type == "inc" }.sumOf { it.amt }
    val exp = inRange.filter { it.type == "exp" }.sumOf { it.amt }

    val tabType = if (tab == 0) "exp" else "inc"
    val byCat = inRange.filter { it.type == tabType }.groupBy { it.cat }.map { it.key to it.value.sumOf { x -> x.amt } }.sortedByDescending { it.second }
    val tabTotal = byCat.sumOf { it.second }
    val rows = inRange.filter {
        (typeF == "all" || it.type == typeF) && (catF.isEmpty() || it.cat == catF) &&
            (q.isBlank() || (it.note + " " + it.cat).contains(q, ignoreCase = true))
    }.sortedByDescending { it.date }

    // trend: expenses of the last 7 days ending at the period end (not after today)
    val end = if (b.isAfter(now)) now else b
    val days = (6 downTo 0).map { end.minusDays(it.toLong()) }
    val trend = days.map { dd -> d.tx.filter { it.type == "exp" && it.date == dd.toString() }.sumOf { it.amt } }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Segmented(listOf("Daily", "Weekly", "Monthly", "Quarterly", "Yearly"), mode, { mode = it; off = 0; catF = "" }, size = 14) }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(14.dp)).clickable { off-- }.padding(10.dp)) { Ico("lf", 30.dp) }
                Spacer(Modifier.width(4.dp))
                if (mode == 0) DateField(sa, "Date", { v -> off = ChronoUnit.DAYS.between(now, LocalDate.parse(v)).toInt(); catF = "" }, Modifier.weight(1f))
                else PickPill(label, {}, Modifier.weight(1f))
                Spacer(Modifier.width(4.dp))
                Box(Modifier.clip(RoundedCornerShape(14.dp)).clickable { if (off < 0) off++ }.padding(10.dp)) { Ico("rt", 30.dp) }
            }
        }
        item { Muted(if (mode == 0) sa else "$sa → $sb", Modifier.padding(start = 4.dp), 17) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AppCard(Modifier.weight(1f)) { Muted("Income", size = 17); Text(money(d.cur, inc), color = Green, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
                AppCard(Modifier.weight(1f)) { Muted("Expenses", size = 17); Text(money(d.cur, exp), color = Red, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
            }
        }
        item {
            AppCard {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("Spending trend", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Muted(" · last 7 days", size = 15)
                }
                Muted(if (d.limit > 0) "dashed line = daily limit" else "Set a daily limit in Settings to see it here", Modifier.padding(top = 4.dp), 16)
                Spacer(Modifier.height(10.dp))
                TrendChart(trend, d.limit, c.primary)
                Row(Modifier.fillMaxWidth()) {
                    days.forEach { dd -> Text(dd.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale.US), Modifier.weight(1f), textAlign = TextAlign.Center, color = c.onSurfaceVariant, fontSize = 14.sp) }
                }
            }
        }
        item {
            AppCard {
                Text("Category allocation", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Spacer(Modifier.height(12.dp))
                Segmented(listOf("Expenses", "Income"), tab, { tab = it; catF = "" })
                Spacer(Modifier.height(16.dp))
                if (byCat.isEmpty()) Muted("Nothing in this period.", Modifier.padding(8.dp), 16)
                else Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                        Donut(byCat.map { it.second }, 150.dp, 34.dp)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) { Muted("Total", size = 13); Text(short(tabTotal), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp) }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        byCat.take(8).forEachIndexed { i, (cat, v) ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { catF = if (catF == cat) "" else cat }
                                    .background(if (catF == cat) c.primary.copy(alpha = 0.12f) else Color.Transparent).padding(vertical = 6.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(10.dp).clip(CircleShape).background(ChartColors[i % ChartColors.size]))
                                Spacer(Modifier.width(10.dp))
                                Text(cat, Modifier.weight(1f), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${if (tabTotal > 0) (v / tabTotal * 100).toInt() else 0}%", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            }
                        }
                    }
                }
                Muted("Tap a category to filter the list below", Modifier.padding(top = 14.dp), 16)
            }
        }
        item { Text("Transactions", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
        item { PillField(q, { q = it }, "Search…") }
        item {
            Dropdown(
                when (typeF) { "exp" -> "Expenses"; "inc" -> "Income"; else -> "All" },
                listOf("all" to "All", "exp" to "Expenses", "inc" to "Income"), { typeF = it }
            )
        }
        item { TxList(rows, d.cur, onOpen) }
    }
}

@Composable
fun TrendChart(values: List<Double>, limit: Double, color: Color) {
    val c = MaterialTheme.colorScheme
    val maxV = maxOf(values.maxOrNull() ?: 0.0, limit, 1.0) * 1.12
    val h = 150.dp
    Box(Modifier.fillMaxWidth().height(h)) {
        Canvas(Modifier.fillMaxSize()) {
            val padX = size.width / (values.size * 2f)
            val stepX = if (values.size > 1) (size.width - 2 * padX) / (values.size - 1) else 0f
            fun yOf(v: Double) = (size.height - 10f) - ((v / maxV).toFloat() * (size.height - 20f))
            val pts = values.mapIndexed { i, v -> Offset(padX + stepX * i, yOf(v)) }
            if (limit > 0) drawLine(Red, Offset(padX * 0.4f, yOf(limit)), Offset(size.width - padX * 0.4f, yOf(limit)), strokeWidth = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f)))
            val fill = Path().apply {
                moveTo(pts.first().x, size.height - 10f)
                pts.forEach { lineTo(it.x, it.y) }
                lineTo(pts.last().x, size.height - 10f)
                close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.18f), Color.Transparent)))
            val line = Path().apply { pts.forEachIndexed { i, p -> if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) } }
            drawPath(line, color, style = Stroke(6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            pts.forEach { p ->
                drawCircle(Color.White, 11f, p)
                drawCircle(color, 11f, p, style = Stroke(5f))
            }
        }
        if (limit > 0) {
            val frac = (1 - (limit / maxV)).toFloat()
            Text("Limit " + short(limit), color = Red, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.align(Alignment.TopEnd).offset(y = ((frac * (h.value - 20f)) - 12f).dp))
        }
    }
}

@Composable
fun Donut(values: List<Double>, size: Dp, stroke: Dp) {
    val total = values.sum()
    Canvas(Modifier.size(size)) {
        val sw = stroke.toPx()
        val inset = sw / 2f
        var start = -90f
        values.forEachIndexed { i, v ->
            val sweep = if (total > 0) (v / total * 360f).toFloat() else 0f
            drawArc(ChartColors[i % ChartColors.size], start, sweep, false, Offset(inset, inset), Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw))
            start += sweep
        }
    }
}

/* ============================== SETTINGS ============================== */

@Composable
fun SetRow(icon: String, title: String, sub: String, open: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit = {}) {
    val c = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(onClick = onToggle).padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconTile(icon, 54.dp, 34.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                Muted(sub, size = 16)
            }
            androidx.compose.material3.Icon(if (open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null, tint = c.onSurface)
        }
        if (open) Column(Modifier.padding(bottom = 12.dp), content = content)
    }
}

@Composable
fun SetGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        SmallLabel(title, Modifier.padding(start = 8.dp, bottom = 10.dp))
        AppCard(pad = 16.dp, content = content)
    }
}

@Composable
fun ColorChip(label: String, i: Int, onDelete: (() -> Unit)?) {
    val col = ChartColors[((label.hashCode() and 0x7fffffff) + i) % ChartColors.size]
    Row(
        Modifier.clip(RoundedCornerShape(22.dp)).background(col.copy(alpha = 0.14f)).padding(start = 18.dp, end = 12.dp, top = 11.dp, bottom = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = col, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        if (onDelete != null) {
            Spacer(Modifier.width(8.dp))
            Box(Modifier.clip(CircleShape).clickable { onDelete() }) { Ico("x", 22.dp) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(st: Store) {
    val d = st.d
    val c = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("") }
    var openKey by remember { mutableStateOf("") }
    var newAcc by remember { mutableStateOf("") }
    var newExp by remember { mutableStateOf("") }
    var newInc by remember { mutableStateOf("") }
    var reset by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(false) }
    var ren by remember { mutableStateOf<String?>(null) }
    fun tog(k: String) { openKey = if (openKey == k) "" else k }

    val exportJson = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) msg = runCatching {
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(d.toJson().toString(2).toByteArray()) }
            "Backup saved."
        }.getOrElse { "Could not save the backup." }
    }
    val exportCsv = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) msg = runCatching {
            val sb = StringBuilder("Date,Type,Category,Account,Item,Amount\n")
            fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
            d.tx.sortedBy { it.date }.forEach { sb.append("${it.date},${it.type},${q(it.cat)},${q(it.acc)},${q(it.note)},${it.amt}\n") }
            ctx.contentResolver.openOutputStream(uri)!!.use { it.write(sb.toString().toByteArray()) }
            "CSV saved."
        }.getOrElse { "Could not save the CSV." }
    }
    val importer = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) msg = runCatching {
            val text = ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes()) }
            val nd = dataFromJson(org.json.JSONObject(text))
            st.up { nd.copy(onboarded = true) }
            "Backup restored."
        }.getOrElse { "That file is not a valid backup." }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LogoTile(72.dp)
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name.ifBlank { "Your name" }, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                        Muted("myWallet profile", size = 16)
                    }
                    Text(
                        "Edit", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                        modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(c.surfaceVariant).clickable { editName = true }.padding(horizontal = 22.dp, vertical = 16.dp)
                    )
                }
            }
        }
        item {
            SetGroup("Preferences") {
                SetRow("th", "Appearance", "Mode and accent color", openKey == "ap", { tog("ap") }) {
                    SmallLabel("Mode"); Spacer(Modifier.height(8.dp))
                    Segmented(listOf("System", "Light", "Dark"), when (d.theme) { "light" -> 1; "dark" -> 2; else -> 0 }, { i -> st.up { it.copy(theme = listOf("auto", "light", "dark")[i]) } })
                    Spacer(Modifier.height(16.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Accents.forEachIndexed { i, col ->
                            Box(
                                Modifier.size(44.dp).clip(CircleShape).background(Color(col))
                                    .border(if (d.accent == i) 4.dp else 0.dp, c.onSurface, CircleShape)
                                    .clickable { st.up { it.copy(accent = i) } }
                            )
                        }
                    }
                }
                HorizontalDivider(color = c.outline)
                SetRow("cur", "Currency", d.cur, openKey == "cu", { tog("cu") }) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("IDR", "USD", "EUR", "GBP", "JPY", "SGD", "MYR", "AUD", "INR").forEach { k -> Chip(k, d.cur == k, { st.up { it.copy(cur = k) } }) }
                    }
                }
                HorizontalDivider(color = c.outline)
                SetRow("gg", "Daily limit", if (d.limit > 0) money(d.cur, d.limit) else "Off", openKey == "dl", { tog("dl") }) {
                    var lim by remember { mutableStateOf(if (d.limit > 0) numText(d.limit) else "") }
                    PillField(lim, { v -> lim = v; st.up { it.copy(limit = v.trim().replace(',', '.').toDoubleOrNull() ?: 0.0) } }, "0 = off", number = true)
                }
            }
        }
        item {
            SetGroup("Categories") {
                SetRow("tag", "Expense categories", "${d.expCats.size} categories", openKey == "ec", { tog("ec") }) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        d.expCats.forEachIndexed { i, k -> ColorChip(k, i) { st.up { s -> s.copy(expCats = s.expCats - k) } } }
                    }
                    Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        PillField(newExp, { newExp = it }, "Add category", modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(10.dp))
                        AddBtn { val n = newExp.trim(); if (n.isNotEmpty() && n !in d.expCats) st.up { it.copy(expCats = it.expCats + n) }; newExp = "" }
                    }
                }
                HorizontalDivider(color = c.outline)
                SetRow("tag", "Income categories", "${d.incCats.size} categories", openKey == "ic", { tog("ic") }) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        d.incCats.forEachIndexed { i, k -> ColorChip(k, i) { st.up { s -> s.copy(incCats = s.incCats - k) } } }
                    }
                    Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        PillField(newInc, { newInc = it }, "Add category", modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(10.dp))
                        AddBtn { val n = newInc.trim(); if (n.isNotEmpty() && n !in d.incCats) st.up { it.copy(incCats = it.incCats + n) }; newInc = "" }
                    }
                }
            }
        }
        item {
            SetGroup("Money") {
                SetRow("bank", "Money places", "${d.accts.size} places", openKey == "mp", { tog("mp") }) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        d.accts.forEachIndexed { i, k ->
                            Box(Modifier.clickable { ren = k }) { ColorChip(k, i, if (d.accts.size > 1) ({ st.up { s -> s.copy(accts = s.accts - k) } }) else null) }
                        }
                    }
                    Muted("Tap a name to rename. Tap a card on Home to set its starting balance.", Modifier.padding(top = 10.dp), 15)
                    Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        PillField(newAcc, { newAcc = it }, "Name, e.g. BCA, GoPay", modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(10.dp))
                        AddBtn { val n = newAcc.trim(); if (n.isNotEmpty() && n !in d.accts) st.up { it.copy(accts = it.accts + n) }; newAcc = "" }
                    }
                }
                HorizontalDivider(color = c.outline)
                SetRow("swap", "Transfers", "${d.xf.size} transfers", openKey == "xf", { tog("xf") }) {
                    if (d.xf.isEmpty()) Muted("No transfers yet. Use the Transfer tab when adding a transaction.", size = 15)
                    d.xf.sortedByDescending { it.date }.forEach { z ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("${z.from} → ${z.to}", fontWeight = FontWeight.Bold); Muted(z.date) }
                            Text(money(d.cur, z.amt), fontWeight = FontWeight.Bold)
                            Box(Modifier.clip(RoundedCornerShape(10.dp)).clickable { st.up { s -> s.copy(xf = s.xf.filter { it.id != z.id }) } }.padding(6.dp)) { Ico("tr", 24.dp) }
                        }
                    }
                }
            }
        }
        item {
            SetGroup("Data") {
                SetRow("bk", "Backup & import", "Save to or restore from a file", openKey == "bk", { tog("bk") }) {
                    Muted("Backups include transactions, goals, budgets and settings (not receipt photos).", Modifier.padding(bottom = 10.dp), 15)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { exportJson.launch("mywallet-backup.json") }, shape = RoundedCornerShape(16.dp)) { Text("Save backup") }
                        OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) }, shape = RoundedCornerShape(16.dp)) { Text("Restore") }
                    }
                    if (msg.isNotEmpty()) Muted(msg, Modifier.padding(top = 8.dp), 15)
                }
                HorizontalDivider(color = c.outline)
                SetRow("dl", "Export to CSV", "Spreadsheet-ready file", openKey == "csv", { tog("csv") }) {
                    Button(onClick = { exportCsv.launch("mywallet.csv") }, shape = RoundedCornerShape(16.dp)) { Text("Export CSV") }
                    if (msg.isNotEmpty()) Muted(msg, Modifier.padding(top = 8.dp), 15)
                }
                HorizontalDivider(color = c.outline)
                SetRow("rs", "Reset", "Delete all transactions", openKey == "rs", { tog("rs") }) {
                    Button(onClick = { reset = true }, colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(16.dp)) { Text("Reset all data") }
                }
            }
        }
        item {
            SetGroup("Support") {
                SetRow("info", "About", "myWallet native v1.0", openKey == "ab", { tog("ab") }) {
                    Muted("Track spending, daily limit, budgets, saving goals and reports. Your data stays on this phone.", size = 15)
                }
            }
        }
    }

    if (reset) AlertDialog(
        onDismissRequest = { reset = false },
        title = { Text("Reset all data?") },
        text = { Text("This deletes every transaction, goal and setting on this device.") },
        confirmButton = { TextButton(onClick = { st.up { Data() }; reset = false }) { Text("Reset", color = Red) } },
        dismissButton = { TextButton(onClick = { reset = false }) { Text("Cancel") } }
    )
    if (editName) {
        var n by remember { mutableStateOf(d.name) }
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text("Edit profile") },
            text = { Field(n, { n = it }, "Your name") },
            confirmButton = { TextButton(onClick = { st.up { it.copy(name = n.trim()) }; editName = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancel") } }
        )
    }
    ren?.let { old ->
        var n by remember(old) { mutableStateOf(old) }
        AlertDialog(
            onDismissRequest = { ren = null },
            title = { Text("Rename money place") },
            text = { Field(n, { n = it }, "Name") },
            confirmButton = {
                TextButton(onClick = {
                    val v = n.trim()
                    if (v.isNotEmpty() && (v == old || v !in d.accts)) st.up { s ->
                        s.copy(
                            accts = s.accts.map { if (it == old) v else it },
                            open = s.open.mapKeys { if (it.key == old) v else it.key },
                            tx = s.tx.map { if (it.acc == old) it.copy(acc = v) else it },
                            rec = s.rec.map { if (it.acc == old) it.copy(acc = v) else it },
                            xf = s.xf.map { it.copy(from = if (it.from == old) v else it.from, to = if (it.to == old) v else it.to) }
                        )
                    }
                    ren = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { ren = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun AddBtn(onClick: () -> Unit) {
    Box(
        Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.primary).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Ico("pl", 34.dp) }
}
